test/
  ├── test.py     # Python 测试客户端
  └── test.html   # HTML 测试页面 