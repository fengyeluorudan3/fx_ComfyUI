"""
通用用法预处理模块，用于将 AgentRequest 转换为 LlmRequest。
"""

import re
import json
from abc import abstractmethod

from fx_agent_core.messages import AgentRequest, AgentResponse, LlmRequest
from fx_lang_ex.utils.log_utils import logger, AgentLog, log_exec_time
from fx_lang_ex.tools.fx_tool import BATool


class BaseGeneralPreprocessor(object):
    """
    通用用法预处理基类，用于对 AgentRequest 进行预处理，以获取规范信息。
    """

    def __init__(self, conf: dict = None):
        """
        初始化方法。

        Args:
            conf: dict, 配置
        Returns:
            None
        """
        self.conf = conf

    @abstractmethod
    def preprocess(self, agent_request: AgentRequest, **kwargs):
        """
        预处理方法。

        Args:
            agent_request: AgentRequest, agent 请求
            kwargs: dict, 其他参数
        Returns:
            llm_request: LlmRequest, 大模型输入
        """
        pass


class ReactAgentGeneralPreprocessor(BaseGeneralPreprocessor):
    """
    React Agent 通用预处理工具类，可用于 ReactAgent 及其子类的通用输入处理。
    """

    def __init__(self, conf: dict = None):
        """
        初始化方法。

        Args:
            conf: dict, 配置
        Returns:
            None
        """
        super(ReactAgentGeneralPreprocessor, self).__init__(conf)

    def preprocess(
        self,
        agent_request: AgentRequest,
        resources,
        tools: list[BATool] = None,
        running_config: dict = None,
    ):

        print("preprocess_preprocess_tools",tools)
        """
        预处理方法。

        Args:
            agent_request: AgentRequest, Agent 请求信息
            running_config: dict, 运行时配置

        Returns:
            llm_request: LlmRequest, LLM 请求信息
        """
        # 1. 处理 system prompt
        system_prompt = running_config["system_prompt"]
        slots = re.findall(r"{{[a-zA-Z_]+}}", system_prompt)
        for slot in slots:
            slot_name = slot[2:-2]
            slot_value = running_config.get(slot_name, "")
            if slot_value:
                system_prompt = system_prompt.replace(slot, slot_value)

        # 2. 处理消息
        messages = []

        # 2.1 历史消息
        for history_message in agent_request.history:

            role = history_message.get("role", "")
            if role not in ["user", "assistant"]:
                continue

            if role == "user":
                m = {"role": "user", "content": history_message["content"]}
                messages.append(m)
                continue

            # orig_llm_messages = json.loads(history_message.get("orig_llm_output", "[]"))
            # for orig_m in orig_llm_messages:
            #     m = {
            #         "role": orig_m["role"],
            #         "content": orig_m["content"],
            #     }
            #     m["tool_call"] = orig_m.get("tool_call", {})
            #     messages.append(m)
            if role == "assistant":
                m = {"role": "assistant", "content": history_message["content"]}
                m["tool_call"] = history_message.get("tool_call", {})
                messages.append(m)
                continue
        print("messages:", messages)

        # 3. 处理资源
        artifacts = agent_request.artifacts
        print("==================",artifacts)


        # TODO: 按需取模型概览信息，本期暂不接入
        llm_request = LlmRequest(
            system=system_prompt,
            messages=messages,
            artifacts=artifacts,
            tools=[tool.get_tool_schema() for tool in tools] if tools else [],
            _copilot_infos=agent_request.ba_context,
        )

        return llm_request
