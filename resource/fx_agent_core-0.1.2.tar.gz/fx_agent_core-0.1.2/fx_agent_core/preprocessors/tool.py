"""
工具输入预处理模块，用于将 AgentResponse 转换为 ToolRequest。
"""

import re
import json
import uuid
from abc import abstractmethod

from fx_agent_core.messages import AgentRequest, AgentResponse, LlmRequest, ToolRequest


class BaseToolPreprocessor(object):
    """
    工具输入预处理基类，用于将 AgentResponse 转换为 ToolRequest。
    """

    def __init__(self, conf: dict = None):
        """
        初始化方法。

        Args:
            conf: dict, 配置
        Returns:
            None
        """
        self.conf = conf

    @abstractmethod
    def preprocess(self, agent_response, **kwargs):
        """
        预处理方法。

        Args:
            agent_response: AgentResponse, agent 请求信息
            kwargs: dict, 其他参数
        Returns:
            tool_request: ToolRequest, 处理后输入
        """
        pass


class ReactAgentToolPreprocessor(BaseToolPreprocessor):
    """
    React Agent 工具输入预处理器，可用于 ReactAgent 及其间的工具输入规范化逻辑。
    """

    def __init__(self, conf: dict = None):
        """
        初始化方法。

        Args:
            conf: dict, 配置
        Returns:
            None
        """
        super(ReactAgentToolPreprocessor, self).__init__(conf)

    def preprocess(self, agent_response, **kwargs):
        """
        预处理方法。

        Args:
            agent_response: AgentResponse, Agent 请求信息
            running_config: dict, 运行时配置
        Returns:
            tool_request: LLMRequest, LLM 请求信息
        """
        print("我開始執行這邊了~~~",agent_response,kwargs)
        tool_call = agent_response._tool_call
        name = tool_call.get("name", "")
        params = tool_call.get("parameters", {})
        tool_call_id = "tool_call_%s" % self._gen_tool_call_id()
        print("我開始執行這邊了~~~",agent_response,kwargs)

        artifacts = kwargs.get("resources")._resources
        print("我開始執行這邊了~~~",agent_response,kwargs)

        tool_request = ToolRequest(
            name=name,
            params=params,
            tool_call_id=tool_call_id,
            artifacts=artifacts,
        )

        print("我開始執行這邊了~~~",agent_response,kwargs)

        return tool_request

    def _gen_tool_call_id(self) -> str:
        """
        生成工具调用 id.

        Args:
            None
        Returns:
            tool_call_id: str, 工具调用 id
        """
        tool_call_id = str(uuid.uuid4())[:8]
        return tool_call_id
