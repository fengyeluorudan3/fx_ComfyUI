# -*- coding:utf-8 -*-
"""
大模型输出后处理模块。
"""

import asyncio
import re
import json
import uuid
from abc import abstractmethod
import time
from typing import Iterable, AsyncIterable

from fx_agent_core.messages import AgentRequest, AgentResponse, LlmRequest
from fx_agent_core.channel import SolutionResultStreamWriter
from fx_lang_ex.utils.log_utils import logger
import json_repair


class OllamaPostProcessorDelta:
    """
    React 范式 LLM 后处理器。
    """

    def __init__(self, conf: dict = None):
        """
        初始化方法。

        Args:
            conf: dict, 配置
        Returns:
            None
        """
        self.conf = conf
        self.stop_event = asyncio.Event()  # 中止信号

    def stop(self):
        """外部调用可中止流式输出"""
        self.stop_event.set()

    async def streaming_process(
        self,
        llm_response: AsyncIterable[str],
        stream_writer: SolutionResultStreamWriter,
        agent_response: AgentResponse,
        **kwargs,
    ):
        """
        LLM 流式输出后处理。

        Args:
            llm_response: Iterable, LLM 流式输出
            stream_writer: SolutionResultStreamWriter, 流式对象
            agent_response: AgentResponse, Agent response
            kwargs: dict, 其他控制参数，可包含：
                is_first_step: bool, 是否为 react 模式的第一次循环
        Returns:
            None
        """
        react_loop_num = kwargs.get("react_loop_num", 0)
        resources_manager = kwargs.get("resources_manager")
        assistant_msg = {"role": "assistant", "content": "", "tool_call": {}}
        agent_response.delta_content = {
            "step": react_loop_num + 1,
            "content_type": "text",
            "content": "",
        }

        agent_response.orig_llm_output.append(assistant_msg)
        agent_response_content = agent_response.content + "\n" if agent_response.content else agent_response.content
        first_token = True
        is_finished = False

        async for token in llm_response:


            # 用户强制停止
            if self.stop_event.is_set():
                agent_response.finished = True
                agent_response._stop_react_loop = True
                agent_response.delta_content = {
                    "step": react_loop_num + 1,
                    "content_type": "abort",
                    "content": "User aborted streaming",
                }
                await stream_writer.write(agent_response.to_dict())
                await asyncio.sleep(0.01)
                return

            if token == "":
                continue


                # print(event_data)
                # if event_data["status_code"] != 200:
                #     agent_response.code = -2
                #     agent_response.msg = "whale 模型请求失败！"
                #     agent_response._stop_react_loop = True
                #     stream_writer.write(agent_response.to_dict())
                #     return

                # print('chatgpt流式输出的结果为：',agent_response.orig_llm_output[-1]["content"])


            if first_token:
                agent_response.orig_llm_output[-1]["content"] += token
                agent_response.delta_content["content"] = token
                first_token = False
            elif "STREAM_END" not in token:
                agent_response.orig_llm_output[-1]["content"] += token
                agent_response.delta_content["content"] = token
            else:
                pass


            if agent_response.orig_llm_output[-1]["content"] == "Thought":  # 若仅输出了 `Thought`（没有冒号），则继续获取结果
                await stream_writer.write(agent_response.to_dict())
                await asyncio.sleep(0.01)
                continue

            if "STREAM_END" in token and "Final Answer:" in agent_response.orig_llm_output[-1]["content"]:
                is_finished = True
                agent_response.finished = True
                agent_response._stop_react_loop = True
                # ✅ 这里执行一次流式写出，确保前端能感知结束
                await stream_writer.write(agent_response.to_dict())
                await asyncio.sleep(0.01)
                break  # ✅ 结束整个流式循环


            # 处理 react 输出逻辑
            if not self.is_react_mode(agent_response.orig_llm_output[-1]["content"]):
                if agent_response.render_template != "TEXT":
                    agent_response.render_template = "TEXT"
                if is_finished:
                    agent_response.finished = True
                    agent_response._stop_react_loop = True
                agent_response.content = agent_response_content + agent_response.orig_llm_output[-1]["content"]
                await stream_writer.write(agent_response.to_dict())
                await asyncio.sleep(0.01)
                if not agent_response.finished:
                    continue
                return

            # 若输出格式符合 react
            if react_loop_num == 0:
                if "Action:" in agent_response.orig_llm_output[-1]["content"]:
                    agent_response.render_template = "REACT"
                    if not is_finished and (
                        "Observation:" in agent_response.orig_llm_output[-1]["content"] or \
                        "Final Answer:" in agent_response.orig_llm_output[-1]["content"] or \
                        self.checkCompleteAction(agent_response.orig_llm_output[-1]["content"])
                    ):

                        print("===============解析工具调用=====================")
                        self.parse_action(agent_response)
                        break

                    thought = agent_response.orig_llm_output[-1]["content"].split("Action:")[0].strip()
                    agent_response.content = agent_response_content + thought
                    await stream_writer.write(agent_response.to_dict())
                    await asyncio.sleep(0.01)

                elif "Final Answer:" in agent_response.orig_llm_output[-1]["content"]:
                    agent_response.render_template = "TEXT"
                    if is_finished:
                        agent_response.finished = True
                        agent_response._stop_react_loop = True
                    final_answer = agent_response.orig_llm_output[-1]["content"].split("Final Answer:")[-1].strip()
                    agent_response.content = agent_response_content + final_answer
                    await stream_writer.write(agent_response.to_dict())
                    await asyncio.sleep(0.01)
                    if not agent_response.finished:
                        continue
                    return
                else:
                    await stream_writer.write(agent_response.to_dict())
                    await asyncio.sleep(0.01)
                    continue
            else:
                # 后续 REACT 循环
                if "Action:" not in agent_response.orig_llm_output[-1]["content"]:
                    if is_finished:
                        agent_response.finished = True
                        agent_response._stop_react_loop = True
                        continue

                    agent_response.content = (
                        agent_response_content + agent_response.orig_llm_output[-1]["content"].split("Action:")[0]
                    )
                    await stream_writer.write(agent_response.to_dict())
                    await asyncio.sleep(0.01)
                    if agent_response.finished:
                        break
                else:
                    if not is_finished and (
                        "Observation:" in agent_response.orig_llm_output[-1]["content"] or \
                        "Final Answer:" in agent_response.orig_llm_output[-1]["content"] or \
                        self.checkCompleteAction(agent_response.orig_llm_output[-1]["content"])
                    ):
                        print("===============解析工具调用=====================")

                        self.parse_action(agent_response)
                        break

                    thought = agent_response.orig_llm_output[-1]["content"].split("Action:")[0].strip()
                    agent_response.content = agent_response_content + thought
                    await stream_writer.write(agent_response.to_dict())
                    await asyncio.sleep(0.01)


    def handle_multimodel_content(self, agent_response: AgentResponse, message, resources):
        """处理多模态输出"""
        placeholder = ""
        if message.get("mime_type") == "image/png":
            placeholder = resources.add_resource("image", {
                "origin": "local",
                "store_id": message.get("value"),
            })
        return placeholder

    def is_react_mode(self, text: str):
        """判断输出是否包含 react 模式标志"""
        if text.lstrip().startswith("Thought:"):
            return True
        return False

    def parse_action(self, agent_response: AgentResponse):
        """解析 LLM 输出中的工具定义"""
        action_info = agent_response.orig_llm_output[-1]["content"]
        action_info = re.split(r"(Observation:|Final Answer:)", action_info)[0]
        agent_response.orig_llm_output[-1]["content"] = action_info

        split_regex = r"(Thought:|Observation:|Action:|Action Input:|Final Answer:)"
        orig_llm_content = agent_response.orig_llm_output[-1]["content"]
        groups = re.split(split_regex, orig_llm_content)[1:]
        react_infos = {groups[i].strip(): groups[i + 1].strip() for i in range(0, len(groups), 2)}

        print(react_infos)

        tool_call = {"name": react_infos.get("Action:", "").strip()}
        try:
            input_str = react_infos.get("Action Input:", "{}").strip()
            input_str = re.sub(r"[\r\n\s]+", " ", input_str)
            tool_call["parameters"] = json_repair.loads(input_str)
        except Exception as e:
            logger.error(f"Invalid Action Input JSON: {react_infos.get('Action Input:')}, error={e}")
            tool_call["parameters"] = {}
            raise Exception("無效工具輸入")

        agent_response._is_tool_call = True
        agent_response._tool_call = tool_call
        agent_response._stop_react_loop = False
        agent_response.finished = False

        print("============================",agent_response._tool_call)

    def checkCompleteAction(self, text: str):
        """
        检测 Action + 完整 JSON（允许尾部脏字符，如 _STREAM_END_）
        """
        if "Action:" not in text or "Action Input:" not in text:
            return False

        # 先裁掉 STREAM_END
        clean_text = text.replace("_STREAM_END_", "").strip()

        match = re.search(
            r'Action Input:\s*(\{.*\})',
            clean_text,
            re.DOTALL
        )
        if not match:
            return False

        input_str = match.group(1).strip()

        try:
            json.loads(input_str)
            logger.info("[Action Detected] JSON完整（忽略_STREAM_END_）")
            return True
        except json.JSONDecodeError:
            return False
