# -*- coding:utf8 -*-

"""
DAG (Directed Acyclic Graph) 管理器.
用于构建和管理 Agent 执行过程中的节点依赖关系.

注意：DAG 的节点与 Action 执行次数一致
- 节点 1, 2, 3...: 对应第 1, 2, 3... 次工具执行
- 外部输入资源直接从 resources 中查找，不创建 DAG 节点
"""

import re
from typing import Dict, Any, List, Optional, Tuple
from fx_lang_ex.utils.log_utils import logger


class DAGManager:
    """
    DAG 管理器，负责：
    1. 构建 DAG 结构，记录节点间的依赖关系
    2. 解析 Action Input 中的占位符引用（从 resources 中查找）
    3. 生成最终的 prompt 结构

    节点规则：
    - 节点 1, 2, 3...: 对应第 1, 2, 3... 次工具执行
    - DAG 的边与 Action 执行次数一致
    """

    # 占位符匹配模式，如 <image/06d917e6c0>
    _PLACEHOLDER_PATTERN = re.compile(r"<([a-zA-Z0-9_-]+)/([a-f0-9]{10,})>")

    def __init__(self):
        # 节点ID计数器，从 0 开始，每次工具执行后递增
        self._node_counter: int = 0

        # DAG 结构: node_id -> node_config
        # 只包含工具执行节点，从 1 开始
        self._dag: Dict[str, Dict[str, Any]] = {}

        logger.info("[*] [DAGManager] initialized")

    def get_next_node_id(self) -> str:
        """
        获取下一个节点ID.
        节点ID从 1 开始，对应第一次工具执行.

        Returns:
            str: 下一个节点ID
        """
        self._node_counter += 1
        return str(self._node_counter)

    def parse_action_input(
            self,
            node_id:int,
            action_input: Dict[str, Any],
            resources: List[Dict[str, Any]]
    ) -> Tuple[Dict[str, Any], List[str]]:

        parsed_params = {}

        for key, value in action_input.items():
            # 默认原样返回
            resolved = value

            if isinstance(value, str):
                match = self._PLACEHOLDER_PATTERN.match(value)
                if match:
                    res_type, res_id = match.groups()
                    placeholder = f"<{res_type}/{res_id}>"

                    node_info = self._find_resource_by_placeholder(node_id,placeholder, resources)
                    if node_info:
                        index = 0
                        parts = node_info.get("unique_key", "").split("#")
                        if len(parts) >= 3:
                            try:
                                index = int(parts[2])
                            except ValueError:
                                pass

                        resolved = [node_id, index]
                        logger.info(
                            f"[*] [DAGManager] resolved placeholder {placeholder} -> node {node_id}"
                        )

            parsed_params[key] = resolved

        return parsed_params

    def _find_resource_by_placeholder(self, node_id:int,placeholder: str, resources: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """
        从 resources 中查找占位符对应的资源信息.

        Args:
            placeholder: 占位符，如 "<image/abc123>"
            resources: 资源列表

        Returns:
            Optional[Dict]: 包含 node_id, unique_key 等信息的字典，或 None
        """
        # 从 resources 中查找
        for resource in resources:
            if resource.get("placeholder") == placeholder or resource.get("id") == placeholder.strip("<>"):
                # 找到资源，返回节点信息
                # 使用 resource 中的 unique_key 字段
                key = resource.get("key")

                # 从 unique_key 解析 node_id


                return {
                    "node_id": node_id,
                    "unique_key": str(node_id) + "#" + key + "#" + "0",
                    "resource": resource
                }

        return None



    def add_tool_execution(self, tool_name: str, action_input: Dict[str, Any]
                          , resources: List[Dict[str, Any]]) -> str:
        """
        添加工具执行节点到 DAG.

        Args:
            tool_name: 工具名称
            action_input: Action Input 参数
            tool_response: 工具返回结果
            resources: 资源列表

        Returns:
            str: 新节点的ID
        """
        node_id = self.get_next_node_id()


        # 解析 Action Input，获取参数和依赖
        parsed_inputs = self.parse_action_input(node_id,action_input, resources)

        # 构建节点配置
        node_config = {
            "class_type": tool_name,
            "inputs": parsed_inputs
        }

        # 将依赖转换为 [node_id, index] 格式（ComfyUI 风格）
        # unique_key 格式: node_id#node_key#index

        self._dag[node_id] = node_config

        logger.info(f"[*] [DAGManager] added tool execution node: {node_id}, tool: {tool_name}，node_config：{node_config}")
        return node_id

    def get_dag(self) -> Dict[str, Any]:
        """
        获取当前的 DAG 结构.

        Returns:
            Dict[str, Any]: DAG 结构
        """
        return self._dag.copy()

    def get_node_count(self) -> int:
        """
        获取节点数量.

        Returns:
            int: 节点数量
        """
        return len(self._dag)

    def to_prompt_format(self) -> Dict[str, Any]:
        """
        将 DAG 转换为 prompt 格式.

        Returns:
            Dict[str, Any]: prompt 格式的 DAG
        """
        return self._dag.copy()

    def clear(self):
        """
        清空 DAG.
        """
        self._dag.clear()
        self._node_counter = 0
        logger.info("[*] [DAGManager] cleared")
