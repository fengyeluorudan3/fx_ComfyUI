# -*- coding:utf8 -*-

"""
todo 可以被抽象 React 工具执行器.
"""

import asyncio
from typing import Callable, List, Optional
from abc import abstractmethod

from fx_agent_core.messages import AgentRequest, AgentResponse, LlmRequest, ToolRequest, ToolExecution,ToolResponse
from fx_agent_core.channel import SolutionResultStreamWriter
from fx_lang_ex.utils.log_utils import logger, AgentLog, log_exec_time
from fx_lang_ex.tools.fx_tool import BATool



class ReactToolExecutor():
    """
    React 工具执行器.
    """

    def __init__(self):
        """
        初始化方法.

        Args:
            conf: dict, 工具执行器配置

        Returns:
            None

        """
        super(ReactToolExecutor, self).__init__()

    async def execute(self, tool_request: ToolRequest, stream_writer: SolutionResultStreamWriter, tools: list[BATool],
                      agent_response: AgentResponse, react_loop_num: int, resources,plan_manager, **kwargs):
        """
        对话接口.

        Args:
            tool_request: ToolRequest, 工具请求
            stream_writer: SolutionResultStreamWriter, 流式对象
            tool_market: ToolMarket, 工具市场
            agent_response: AgentResponse, Agent response
            postprocess_handler: Callable, 工具后处理方法
            kwargs: dict, 其他参数

        Returns:
            None
            :param react_loop_num:

        """

        # max_exec_time = self.conf.get("max_exec_time", None)    # 工具最大运行时长
        print("開始執行了")

        if not agent_response.artifacts:
            agent_response.artifacts = []

        tool = self.get_tool_by_name(tool_request.name, tools)
        print(tool)
        exection_info = self.get_exection_info(tool_request, tool)
        print(exection_info)
        agent_response.delta_content = {
            "step": react_loop_num + 1,
            "content_type": "execution",
            "content": exection_info
        }
        await stream_writer.write(agent_response.to_dict())
        await asyncio.sleep(0.01)

        # 如果tool还是空，给一个兜底的策略直接返回
        if tool is None:

            # 写入工具执行等待信息到资源管理
            agent_response.content += "\nAction: %s" % (exection_info.get("placeholder", ""))
            agent_response.artifacts.append(exection_info)
            resources.add_resource("execution", exection_info)

            agent_response.delta_content = {
                "step": react_loop_num + 1,
                "content_type": "execution",
                "finished": True,
                "content": exection_info
            }
            await stream_writer.write(agent_response.to_dict())
            await asyncio.sleep(0.01)

            res_content = "暂未找到该场景下合适的工具，请提供更合适的工具信息再试一下～"
            ex_tool_msg = {"role": "tool", "content": res_content}

            agent_response.content += ": %s" % res_content
            agent_response.orig_llm_output.append(ex_tool_msg)
            agent_response.delta_content = {
                "step": react_loop_num + 1,
                "content_type": "text",
                "content": ": %s" % res_content
            }

            # artifact 无需另行更新
            await stream_writer.write(agent_response.to_dict())
            await asyncio.sleep(0.01)

            agent_response.finished = True
            agent_response._stop_react_loop = True
            return

        try:

            if tool == None:
                # TO DO: 工具获取异常处理
                raise Exception("未查询到对应工具信息，请检查工具描述是否完整正确")

            # 写入工具执行等待信息到资源管理
            agent_response.content += "\nAction: %s" % (exection_info.get("placeholder", ""))
            agent_response.artifacts.append(exection_info)
            resources.add_resource("execution", exection_info)


            # 执行工具
            logger.info("[*] [executor] tool request: %s" % (AgentLog.from_tool_request(tool_request).log_content))
            tool_response = tool._run(tool_request)
            logger.info("[*] [executor] tool response: %s" % (AgentLog.from_tool_response(tool_response).log_content))

            # 特殊的工具的处理逻辑
            # 如果调用了write_todos工具，同步到PlanManager
            if tool_request.name == "write_todos" and tool_response.code == 0:
                self._sync_todos_to_plan_manager(tool_request, plan_manager)
                agent_response.delta_content = {
                    "step": react_loop_num + 1,
                    "content_type": "todoList_sync",
                    "content": plan_manager
                }
                await stream_writer.write(agent_response.to_dict())
                await asyncio.sleep(0.01)

            # 写入工具执行结果
            agent_response.delta_content = {
                "step": react_loop_num + 1,
                "content_type": "execution",
                "finished":True,
                "content": exection_info
            }
            await stream_writer.write(agent_response.to_dict())
            await asyncio.sleep(0.01)

            # 获取 DAG Manager 并添加工具执行节点
            try:
                dag_manager = kwargs.get("dag_manager")
                if dag_manager:
                    # 传递 resources._resources 用于占位符查找
                    node_id = dag_manager.add_tool_execution(
                        tool_name=tool_request.name,
                        action_input=tool_request.params,
                        resources=resources._resources
                    )
                    logger.info(f"[*] [executor] added tool execution to DAG, node_id: {node_id}")
            except Exception as e:
                logger.exception("[*] [executor] failed to add tool execution to DAG")


            tool_msg = {"role": "tool", "content": tool_response.res_content}
            resources.add_resource_from_artifacts(tool_response.artifacts)

            agent_response.content += ": %s" % tool_response.res_content
            agent_response.orig_llm_output.append(tool_msg)
            agent_response.delta_content = {
                "step": react_loop_num + 1,
                "content_type": "text",
                "content": ": %s" % tool_response.res_content
            }

            # artifact 无需另行更新
            await stream_writer.write(agent_response.to_dict())
            await asyncio.sleep(0.01)

        except Exception as e:

            # TO DO: 处理超时
            logger.error(f"tool_execute_error error={str(e)}", exc_info=True)

            agent_response.orig_llm_output.append({"role": "tool", "content": str(e)})
            agent_response.delta_content = {
                "step": react_loop_num + 1,
                "content_type": "execution",
                "error": str(e),
                "finished": True,
                "content": exection_info
            }

            await stream_writer.write(agent_response.to_dict())
            await asyncio.sleep(0.01)
            agent_response.finished = True
            agent_response._stop_react_loop = True

        return

    def get_tool_by_name(self, name: str, tools: List[BATool]) -> BATool:
        """
        根据工具名称获取工具实例

        :param name: 工具名称
        :param tools: 工具列表
        :return: 工具实例，如果未找到返回 None
        """
        for tool in tools:
            schema = tool.get_tool_schema()
            if schema.get("name") == name:
                return tool

        #兜底逻辑
        tool_names = [tool.get_tool_schema().get("name") for tool in tools]
        match_name = best_match(name, tool_names)

        if match_name is None:
            return None

        for tool in tools:
            if tool.get_tool_schema().get("name") == match_name:
                return tool

        return None

    def get_exection_info(self, tool_request: ToolRequest, tool: BATool):
        """
        获取工具执行时信息.

        Args:
            tool_request: ToolRequest, 工具执行请求信息
            tool_info: dict, 工具信息

        Returns:
            exection_info: dict, 工具执行信息

        """
        if tool is None:
            exection_info = ToolExecution(
                tool_name=tool_request.name,
                tool_parameters=tool_request.params,
                running_text="处理中 ...",
                finish_text="已完成。"
            )
        else:
            tool_schema = tool.get_tool_schema()
            tool_name = tool_request.name
            tool_parameters = tool_request.params
            running_text = tool_schema.get("running_text", "处理中 ...")
            finish_text = tool_schema.get("finish_text", "已完成。")

            exection_info = ToolExecution(
                tool_name=tool_name,
                tool_parameters=tool_parameters,
                running_text=running_text,
                finish_text=finish_text
            )
        exection_info = exection_info.to_dict()

        return exection_info
    
    def _sync_todos_to_plan_manager(self, tool_request: ToolRequest, plan_manager):
        """
        将write_todos的结果同步到PlanManager
        
        Args:
            tool_request: ToolRequest，包含todos参数
            resources: ResourceManager，可能包含plan_manager
        """
        try:
            # 从tool_request中获取todos
            params = tool_request.params or {}
            todos = params.get("todos", [])
            
            if not todos:
                return

            # 同步todos到PlanManager
            plan_manager.sync_from_todos(todos)
            logger.info(f"[ReactToolExecutor] Synced {len(todos)} todos to PlanManager")
            
        except Exception as e:
            logger.warning(f"[ReactToolExecutor] Failed to sync todos to PlanManager: {e}")
