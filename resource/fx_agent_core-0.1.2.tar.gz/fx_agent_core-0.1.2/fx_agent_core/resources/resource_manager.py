import uuid
import logging
from typing import Dict, Any, List, Optional
import re

logger = logging.getLogger(__name__)


class ResourceManager:
    """
    一个资源中心，统一管理 agent 中用到的 artifacts（图片/视频/音频/文本等）。
    采用扁平存储结构，每个资源包含自身的类型信息。
    """

    _PLACEHOLDER_PATTERN = re.compile(r"^<([a-zA-Z0-9_-]+)/([a-f0-9]{10,})>$")

    def __init__(self):
        """存储为扁平 list，每个元素是 dict，包含 type/placeholder 等字段"""
        self._resources: List[Dict[str, Any]] = []

    def add_resource(self, res_type: str, resource_data: dict) -> str:
        """
        添加一个资源。

        Args:
            res_type: 资源类型，例如 "image", "video", "audio", "text"
            resource_data: dict, 资源数据, 至少包含 {id?, url?, origin?}
        Returns:
            str: 资源 placeholder
        """
        res_id, _id = ResourceManager.gen_artifact_placeholder(res_type)
        resource_data["type"] = res_type
        resource_data.setdefault("id", _id)
        resource_data.setdefault("placeholder", res_id)

        self._resources.append(resource_data)
        return res_id

    def add_resource_from_artifacts(self, artifacts: List[Dict[str, Any]]) -> List[str]:
        """
        根据 artifacts 列表添加多个资源。
        如果已有相同 id 的资源则跳过。

        Args:
            artifacts: list[dict], 每个元素至少包含 {url?, origin?, type?}
        Returns:
            list[str]: 新增的资源 placeholder 列表
        """
        added_placeholders = []

        for artifact in artifacts:
            res_type = artifact.get("type", "text")
            placeholder = artifact.get("placeholder")

            if placeholder:
                res_id = placeholder.strip("<>")
            else:
                placeholder, res_id = ResourceManager.gen_artifact_placeholder(res_type)

            artifact["id"] = res_id
            artifact["type"] = res_type
            artifact["placeholder"] = placeholder

            self._resources.append(artifact)
            added_placeholders.append(placeholder)
            logger.info(f"[*] Added new resource: {artifact}")

        return added_placeholders

    def get_resource(self, res_id: str) -> Optional[Dict[str, Any]]:
        """根据资源 ID 或 placeholder 获取资源。"""
        for item in self._resources:
            if item.get("id") == res_id or item.get("placeholder") == res_id:
                return item
        return None

    def list_resources(self, res_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        列出所有资源，或指定类型的资源。
        """
        if res_type:
            return [item for item in self._resources if item.get("type") == res_type]
        return self._resources

    def remove_resource(self, res_id: str) -> bool:
        """
        删除一个资源（通过 id 或 placeholder）
        Returns:
            bool: 是否成功删除
        """
        for i, item in enumerate(self._resources):
            if item.get("id") == res_id or item.get("placeholder") == res_id:
                del self._resources[i]
                logger.info(f"[*] Removed resource: {res_id}")
                return True
        return False

    def to_dict(self) -> List[Dict[str, Any]]:
        """输出为列表形式。"""
        return self._resources

    def get_id2artifact(
        self,
        artifacts: List[Dict[str, Any]],
        artifact_type: str = None
    ) -> Dict[str, Any]:
        """
        获取 placeholder 到 artifact 的映射。
        Args:
            artifacts: list[dict], 资源列表
            artifact_type: str, 可选，指定类型
        Returns:
            dict: {placeholder: artifact}
        """
        id2artifact = {}
        for artifact in artifacts:
            if artifact_type and artifact.get("type") != artifact_type:
                continue
            placeholder = artifact.get("placeholder", "")
            if placeholder:
                id2artifact[placeholder] = artifact
        return id2artifact

    @classmethod
    def gen_artifact_placeholder(cls, artifact_type: str) -> (str, str):
        """生成资源 placeholder"""
        _id = str(uuid.uuid4()).replace("-", "")[:10]
        artifact_placeholder = f"<{artifact_type}/{_id}>"
        return artifact_placeholder, _id

    @classmethod
    def is_placeholder(cls, text: str) -> bool:
        """
        判断一个字符串是否是资源 placeholder 格式，例如 <image/123abc4567>
        Args:
            text (str): 待检测字符串
        Returns:
            bool: 是否为 placeholder
        """
        if not isinstance(text, str):
            return False
        return bool(cls._PLACEHOLDER_PATTERN.match(text))

    def precheck_resource(self, res_type: str, resource_data: dict) -> bool:
        """
        判断一个字符串是否是资源 placeholder 格式，例如 <image/123abc4567>
        """
        if res_type in ("image", "video"):
            if resource_data.get("store_id") == "":
                raise ValueError(f"{res_type} 资源的 store_id 不能为空字符串")
        return True
