"""
工具相关消息定义。
"""

import uuid
import json
from dataclasses import dataclass, field
from typing import Optional

from fx_lang_ex.utils.str_utils import *


@dataclass
class RunConfig(object):
    """
    工具运行配置。
    """
    pass


@dataclass
class ToolRequest(object):
    """
    工具请求。
    """

    name: str = ""                    # 申请调用工具的名称
    params: dict = field(default_factory=dict)  # 申请调用工具的参数列表
    tool_call_id: str = ""            # 工具调用 id
    artifacts: list = field(default_factory=list)  # 请求中涉及的非文本数据
    run_config: Optional[RunConfig] = None        # 运行时配置
    msg_type: str = "ToolRequest"     # 消息类型
    _copilot_infos: dict = None       # copilot 请求相关信息，用于打印日志

    def __str__(self):
        """
        对 request 进行字符串化，以便于显示。
        """
        tool_request_dict = {}
        for attr_ in vars(self):
            if attr_.startswith("_"):
                continue
            tool_request_dict[attr_] = getattr(self, attr_, None)

        request_dict = prepare_obj_for_jsonify(tool_request_dict)
        request_str = json.dumps(request_dict, ensure_ascii=False)
        return request_str


@dataclass
class ToolResponse(object):
    """
    工具响应，即工具执行结果。
    """

    name: str = ""                    # 调用的工具名称
    params: dict = field(default_factory=dict)  # 工具参数
    tool_call_id: str = ""            # 工具调用 id
    code: int = 0                     # 工具执行状态码
    msg: str = ""                     # 工具执行状态信息
    res_datas: dict = field(default_factory=dict)   # 工具执行的原始结果
    res_content: str = ""             # 工具执行的文本化结果（LLM输入）
    artifacts: list = field(default_factory=list)   # 请求中涉及的非文本数据
    run_config: Optional[RunConfig] = None          # 运行配置
    msg_type: str = "ToolResponse"    # 消息类型
    _copilot_infos: dict = None       # copilot 请求相关信息，用于打印日志

    def __str__(self):
        """
        对 response 进行字符串化，以便显示。
        """
        tool_response_dict = {}
        for attr_ in vars(self):
            if attr_.startswith("_"):
                continue
            tool_response_dict[attr_] = getattr(self, attr_, None)

        response_dict = prepare_obj_for_jsonify(tool_response_dict)
        response_str = json.dumps(response_dict, ensure_ascii=False)
        return response_str


@dataclass
class ToolExecution(object):
    """
    工具执行信息。
    """

    id: str = ""                      # Execution id
    placeholder: str = ""             # 占位符
    tool_name: str = ""               # 工具名称
    tool_parameters: dict = None      # 工具参数
    running_text: str = ""            # 工具运行时显示的文本
    finish_text: str = ""             # 工具执行完成后显示的文本
    finished: bool = False            # 是否执行完成
    type: str = "execution"           # 消息类型

    def __post_init__(self):
        """
        初始化后操作。
        """
        _id = str(uuid.uuid4()).replace("-", "")[:8]
        self.id = f"{self.type}/{_id}"
        self.placeholder = f"<{self.id}>"

    def to_dict(self):
        """
        用于将工具执行信息转换为 dict 形式。
        """
        tool_execution_dict = {}
        for attr_ in vars(self):
            if attr_.startswith("_"):
                continue
            tool_execution_dict[attr_] = getattr(self, attr_, None)
        return tool_execution_dict
