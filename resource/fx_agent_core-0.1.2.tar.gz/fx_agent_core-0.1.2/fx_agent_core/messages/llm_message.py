"""
LLM / chat model 消息。
"""

import copy
from dataclasses import dataclass


@dataclass
class LlmRequest(object):
    """
    大模型请求。
    """

    system: str = ""        # system prompt
    messages: list = None   # 用户对话历史
    tools: list = None      # 可用工具
    artifacts: list = None  # 结构化数据或信息
    _copilot_infos: dict = None  # copilot 请求相关信息，用于打印日志，便于追溯问题

    def to_dict(self):
        """
        用于将 LlmRequest 转换为 dict 形式。
        """
        llm_request_dict = {}
        for attr_ in vars(self):
            if attr_.startswith("_"):
                continue
            llm_request_dict[attr_] = getattr(self, attr_, None)
        return llm_request_dict

    def __deepcopy__(self, memo):
        """
        复制大模型请求信息。
        Args:
            memo: 参数传值对象
        Returns:
            object_copy: 对象副本
        """
        attrs = {}
        for attr_ in vars(self):
            attrs[attr_] = copy.deepcopy(getattr(self, attr_, None), memo)
        object_copy = LlmRequest(**attrs)
        return object_copy


@dataclass
class LlmResponse(object):
    """
    大模型响应。
    """

    def to_dict(self):
        """
        用于将 LlmResponse 转换为 dict 形式。
        """
        agent_response_dict = {}
        for attr_ in vars(self):
            if attr_.startswith("_"):
                continue
            agent_response_dict[attr_] = getattr(self, attr_, None)
        return agent_response_dict
