"""
Agent 基础信息模块，包含 BA Agent 请求/响应的相关定义。
"""

import time
import hashlib
import uuid
from dataclasses import dataclass

from fx_lang_ex.constant import *


@dataclass
class AgentRequest(object):
    """
    Agent 请求。
    """

    query: str = ""  # 当前用户 query
    history: list = None  # 对话历史
    agent_infos: dict = None  # copilot 请求相关信息，用于打印日志
    chat_model_info: dict = None  # copilot 请求相关信息，用于打印日志
    tools: list = None  # 外部用户选择的工具集合
    artifacts: list = None  # 附件数据
    ba_context: dict = None  # BA上下文信息

    @classmethod
    def from_copilot_request(cls, copilot_context, resources):
        """
        将 copilot 请求转化为 Agent 请求。

        Args:
            copilot_context: copilotContext, copilot 请求参数
        """
        code = ResponseCode.SUCCESS.code
        msg = ResponseCode.SUCCESS.msg
        agent_request = None

        try:
            params = copilot_context.get("request", "{}")

            # 为了适配后端，临时处理
            history = params.get("history")
            query = params.get("query")
            ba_context = copilot_context.get("ba_context")

            if query is None or query == "":
                code = ResponseCode.INVALID_PARAM.code
                msg = ResponseCode.INVALID_PARAM.msg
                return code, msg, agent_request


            if history is None:
                history = [
                    {
                        "role": "user",
                        "content": query.strip(),
                        "msg_id": str(uuid.uuid4()),
                        "content_type": "text",
                    }
                ]

            artifacts = resources.to_dict()

        except Exception as e:

            logger.error(f"Error while generating response: {e}")

            code = ResponseCode.SERVER_ERROR.code
            msg = ResponseCode.SERVER_ERROR.msg
            return code, msg, agent_request

        agent_request = cls(
            query=query,
            history=history,
            artifacts=artifacts,
            ba_context=ba_context,
        )
        return code, msg, agent_request

    def to_dict(self):
        """
        用于将 AgentRequest 转换为 dict 形式。
        """
        agent_request_dict = {}
        for attr_ in vars(self):
            if attr_.startswith("_"):
                continue
            agent_request_dict[attr_] = getattr(self, attr_, None)
        return agent_request_dict


@dataclass
class AgentResponse(object):
    """
    Agent 响应。
    """

    session_id: str = ""  # Session ID
    related_user_msg_id: str = ""  # 与当前 response 关联的用户消息 id
    msg_id: str = ""  # 消息 id
    render_template: str = ""  # 渲染模板
    content: str = ""  # 消息内容
    delta_content: dict = None  # 消息内容差异
    orig_llm_output: list = None  # 原始模型输出
    artifacts: list = None  # 额外结果
    tools: list = None  # 使用的工具
    finished: bool = False  # 输出是否已完全结束
    agent_id: str = ""  # 实际执行者的 agent id
    agent_name: str = ""  # 实际执行者的 agent 名称
    code: int = 0  # 错误代码
    msg: str = "OK"  # 错误信息
    _copilot_infos: dict = None  # copilot 请求相关信息
    _stop_react_loop: bool = False  # 是否停止 react 循环
    _is_tool_call: bool = False  # 当前是否是一个 workflow 工具调用
    _tool_call: dict = None  # 工具调用信息
    agent_result: dict = None  # agent结果评定
    ba_context: dict = None  # BA上下文信息

    def __post_init__(self):
        """
        初始化后操作，用于生成 msg_id。
        """
        session_id = self.session_id
        related_user_msg_id = self.related_user_msg_id

        if not session_id and not related_user_msg_id:
            return

        to_encode = "||".join([session_id, related_user_msg_id, str(time.time())])
        hl = hashlib.md5()
        hl.update(to_encode.encode(encoding="utf-8"))
        self.msg_id = "msg_%s" % hl.hexdigest()
        return

    @classmethod
    def from_error_code(cls, code: int, msg: str, **kwargs):
        """
        基于错误信息，构建 response.

        Args:
            code: int, 错误代码
            msg: str, 错误信息
            kwargs: dict, 其他参数

        Returns:
            agent_response: AgentResponse, a AgentResponse instance.

        """
        agent_request = kwargs.get("agent_request", None)
        agent_response = None

        if not agent_request:
            agent_response = cls(code=code, msg=msg, finished=True)
        else:
            session_id = agent_request.session_id
            related_user_msg_id = agent_request.msg_id
            agent_response = cls(
                session_id=session_id,
                related_user_msg_id=related_user_msg_id,
                finished=True,
                code=code,
                msg=msg,
            )

        return agent_response

    @classmethod
    def from_request(cls, agent_request):
        """
        基于 AgentRequest 初始化 AgentResponse。
        """
        orig_llm_output = []
        tools = []
        delta_content = {}
        ba_context = {}

        agent_response = cls(
            orig_llm_output=orig_llm_output,
            tools=tools,
            delta_content=delta_content,
        )

        return agent_response

    def to_dict(self):
        """
        用于将 AgentResponse 转换为 dict 形式。
        """
        agent_response_dict = {"response": {}}
        for attr_ in vars(self):
            if attr_.startswith("_"):
                continue
            if getattr(self, attr_) is None:
                continue
            if attr_.startswith("artifacts"):
                continue
            if attr_.startswith("content"):
                continue
            if attr_.startswith("orig_llm_output"):
                continue
            agent_response_dict["response"][attr_] = getattr(self, attr_, None)
        return agent_response_dict
