import asyncio
import json
from asyncio import Queue


class SolutionResultStreamWriter:
    """
    流式输出写入器。
    负责将异步生成的事件按顺序写入队列，并支持 SSE 式输出。
    """

    def __init__(self):
        self.queue = Queue()
        self.event_counter = 0  # 自增计数器

    async def write(self, data: dict):
        """
        向队列写入一条事件数据。
        在每条数据外层加上 eventid。
        """
        self.event_counter += 1
        wrapped_data = {
            "eventid": self.event_counter,  # 在最外层加入 eventid
            **data,
        }

        await self.queue.put(wrapped_data)

    async def complete(self):
        """
        向队列写入 None 以表示结束。
        """
        await self.queue.put(None)

    async def stream_generator(self):
        """
        生成一个异步流式生成器，用于按序输出事件。
        """
        try:
            while True:
                # 从队列中获取数据
                data = await self.queue.get()
                if data is None:  # 结束标记
                    break
                yield data
        except Exception as e:
            print(f"Stream generator error: {e}")
