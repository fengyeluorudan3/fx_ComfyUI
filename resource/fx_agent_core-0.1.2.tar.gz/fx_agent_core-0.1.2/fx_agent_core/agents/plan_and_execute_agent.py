"""
ReAct 模型驱动的 FX Agent。
"""

import asyncio
import time
import re
import json
import copy

from fx_lang_ex.utils.log_utils import logger, AgentLog, log_exec_time
from fx_lang_ex.tools.fx_tool import BATool
from fx_lang_ex.chat_models import EgressMultiModelChatModel,MultiModelDoubaoChatModel
from fx_lang_ex.prompt_template import GeneralReactPromptBuilder,GeneralPlanReactPromptBuilder
from fx_agent_core.messages import AgentRequest, AgentResponse, LlmRequest
from fx_agent_core.preprocessors import (
    ReactAgentGeneralPreprocessor,
    ReactAgentToolPreprocessor,
)
from fx_agent_core.postprocessors import (
    EgressMultiReactChatModelPostProcessorDelta,
    OllamaPostProcessorDelta
)
from fx_agent_core.tool_executor import ReactToolExecutor
from fx_agent_core.channel import SolutionResultStreamWriter


class FXPlanReactAgent:
    """
    ReAct 模型驱动的 FX Agent。
    """

    def __init__(self, model_conf: dict, conf: dict = None, **kwargs):
        """
        初始化 FX Agent。
        """
        self.model_conf = model_conf
        self.agent_conf = conf or {}

        # Agent 控制参数
        self.max_react_loop_num = self.agent_conf.get("max_react_loop_num", 3)
        self.asy_prompt = self.agent_conf.get("asy_prompt", "")

        # 初始化组件
        self.chat_model = MultiModelDoubaoChatModel(model_conf)
        self.pre_processor = ReactAgentGeneralPreprocessor()
        self.tool_preprocessor = ReactAgentToolPreprocessor()
        self.tool_executor = ReactToolExecutor()
        self.chat_model_postprocessor = OllamaPostProcessorDelta()
        self.prompt_template = GeneralPlanReactPromptBuilder()

    def stop(self):
        """外部调用可中止流式输出"""
        self.chat_model_postprocessor.stop()

    # @log_exec_time
    async def process(
        self,
        stream_writer: SolutionResultStreamWriter,
        agent_request: AgentRequest,
        resources,
        plan_manager,
        tools: list[BATool] = None,
        **kwargs,
    ):
        """
        主流程入口：执行 ReAct 推理循环。
        """

        logger.info("[*] [react] agent request: %s", AgentLog.from_agent_request(agent_request).log_content)

        # 初始化响应对象
        agent_response = AgentResponse.from_request(agent_request)
        logger.info("[*] [react] init agent_response: %s", AgentLog.from_agent_response(agent_response).log_content)

        # Step 1. 预处理 LLM 请求
        orig_llm_request = self.pre_processor.preprocess(agent_request, resources, tools, self.agent_conf)
        llm_request = copy.deepcopy(orig_llm_request)
        logger.info("[*] [react] agent llm_request: %s", llm_request)

        react_loop_num = 0
        max_loop = self.max_react_loop_num

        # Step 2. 进入循环
        while react_loop_num < max_loop:
            start_time = time.time() * 1000
            logger.info("[*] [react] loop %d llm_request: %s",
                        react_loop_num, AgentLog.from_llm_request(llm_request).log_content)


            await self.generate_stream(
                llm_request,
                stream_writer,
                agent_response,
                react_loop_num=react_loop_num,
                resources_manager=resources,
                plan_manager=plan_manager,
            )

            if agent_response.finished or agent_response._stop_react_loop:
                end_time = time.time() * 1000
                duration = end_time - start_time
                agent_response.delta_content = {
                    "step": react_loop_num + 1,  # 与 postprocessor 一致，使用 1-based step
                    "content_type": "step_elapse",
                    "content": duration,
                }
                agent_response.finished = True
                await stream_writer.write(agent_response.to_dict())
                await asyncio.sleep(0.1)
                await stream_writer.complete()
                break

            # Step 3. 工具调用阶段
            if agent_response._is_tool_call:

                print("我開始執行工具了")
                tool_request = self.tool_preprocessor.preprocess(agent_response, resources=resources)

                print("我完成工具參數準備")
                logger.info("[*] [react] loop %d tool request: %s",
                            react_loop_num, AgentLog.from_tool_request(tool_request).log_content)

                await self.tool_executor.execute(tool_request,
                                                 stream_writer,
                                                 tools,
                                                 agent_response,
                                                 postprocess_handler=None,
                                                 react_loop_num=react_loop_num,
                                                 resources=resources,
                                                 plan_manager=plan_manager
                                                 )
                if agent_response._stop_react_loop:
                    end_time = time.time() * 1000
                    duration = end_time - start_time
                    agent_response.delta_content = {
                        "step": react_loop_num + 1,
                        "content_type": "step_elapse",
                        "content": duration,  # 使用.3f保留小数点后三位,
                    }
                    await stream_writer.write(agent_response.to_dict())
                    await asyncio.sleep(0.1)
                    await stream_writer.complete()
                    break

            # Step 4. 更新上下文并继续下一次 ReAct
            llm_request.messages = orig_llm_request.messages + agent_response.orig_llm_output
            llm_request.artifacts = resources._resources

            end_time = time.time() * 1000
            duration = end_time - start_time
            agent_response.delta_content = {
                "step": react_loop_num + 1,
                "content_type": "step_elapse",
                "content": duration,
            }
            await stream_writer.write(agent_response.to_dict())
            await asyncio.sleep(0.1)

            react_loop_num += 1

        await stream_writer.complete()
        logger.info("[*] [react] agent response: %s",
                    AgentLog.from_agent_response(agent_response).log_content)

    # @log_exec_time
    async def generate_stream(
        self,
        llm_request,
        stream_writer,
        agent_response,
        react_loop_num,
        resources_manager,
        plan_manager
    ):
        """
        生成 LLM 的流式响应。
        """

        logger.info("[*] [chat_model] model request: %s", AgentLog.from_llm_request(llm_request).log_content)

        print(resources_manager)

        # 构造 prompt
        logger.info("[*] [chat_model] model get_todos: \n%s", plan_manager.get_todos_json())
        prompt = self.prompt_template.build_raw_prompt(llm_request.__dict__, self.agent_conf, self.model_conf,plan_manager)
        logger.info("[*] [chat_model] model request prompt: \n%s", prompt)

        # 构建资源信息
        resources = [
            {
                "id": item.get("id"),
                "placeholder": item.get("placeholder"),
                "store_id": item.get("store_id"),
                "type": item.get("type"),
                "origin": item.get("origin"),
            }
            for item in llm_request.__dict__.get("artifacts")
            if item.get("type") == "image"
        ]

        prompt = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]

        try:
            # Step 5. 调用模型生成
            await self.chat_model_postprocessor.streaming_process(
                self.chat_model.generate(
                    messages=prompt,
                    resources=resources,
                    ba_context=llm_request._copilot_infos,
                ),
                stream_writer,
                agent_response,
                react_loop_num=react_loop_num,
                resources_manager=resources_manager,
            )

            logger.info("[*] [chat_model] llm output: %s", AgentLog.from_kv(prompt=prompt, response=agent_response).log_content)

        except Exception as e:
            logger.error(f"Error while generating response: {e}")
            raise e
