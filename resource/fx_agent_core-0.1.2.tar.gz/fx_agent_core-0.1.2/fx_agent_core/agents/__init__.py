"""
Agent 模板。
"""

import importlib
from fx_agent_core.agents.react_agent import FXReactAgent
from fx_agent_core.agents.plan_and_execute_agent import FXPlanReactAgent
from fx_lang_ex.utils.log_utils import logger, AgentLog, log_exec_time


class AgentTemplates(object):
    """
    Agent 模板。
    """

    # 绑定内部的 agent_type -> 类
    AGENT_CLASS_MAP = {
        "fx_react_agent": FXReactAgent,
        "fx_planandexecute_agent": FXPlanReactAgent,
    }

    MOCK_AGENT_CLASS_MAP = {
        "mock_fx_react_agent": FXReactAgent,
    }

    @classmethod
    def config_agent_templates(cls, model_conf: dict, agent_template_conf: dict = None, **kwargs):
        """
        根据配置动态实例化 Agent，返回对象。
        """

        agent_template_conf = agent_template_conf or {}
        agent_type = agent_template_conf.get("agent_type")

        if not agent_type:
            raise ValueError("[!] agent_type 未定义")

        try:
            # 安全动态导入
            agent_cls = cls.AGENT_CLASS_MAP.get(agent_type)
            agent = agent_cls(model_conf, agent_template_conf)
            logger.info("[*] [main] agent_init_success: %s", agent_type)
            return agent

        except Exception as e:
            logger.error("[*] [main] agent_init_error: %s", e)
            raise e

    @classmethod
    def config_mock_agent_templates(cls, model_conf: dict, agent_template_conf: dict = None, **kwargs):
        """
        根据配置动态实例化 Mock Agent，返回对象。
        """

        agent_template_conf = agent_template_conf or {}
        agent_type = agent_template_conf.get("agent_type")

        if not agent_type:
            raise ValueError("[!] mock_agent_type 未定义")

        try:
            # 安全动态导入
            agent_cls = cls.MOCK_AGENT_CLASS_MAP.get("mock_" + agent_type)
            agent = agent_cls()
            logger.info("[*] [main] mock_agent_init_success: %s", agent_type)
            return agent

        except Exception as e:
            logger.error("[*] [main] mock_agent_init_error: %s", e)
            raise e
