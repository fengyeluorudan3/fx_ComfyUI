"""
PlanManager: 管理plan和todo列表的核心类
"""

import json
import os
from typing import Dict, List, Set, Optional, Any
from collections import deque

from fx_lang_ex.utils.log_utils import logger
from .plan_node import PlanNode, TaskStatus


class PlanManager:
    """
    极简 PlanManager：
    - 只维护一个有序 todo list
    - 不处理 DAG / 依赖
    - Agent 友好
    """

    def __init__(self):
        self.todos: List[PlanNode] = []

    # ---------- 基础操作 ----------

    def add_task(self, content: str) -> PlanNode:
        node = PlanNode(
            node_id=f"task_{len(self.todos)}",
            content=content,
            status=TaskStatus.PENDING,
        )
        self.todos.append(node)
        logger.info(f"[PlanManager] Add task: {content}")
        return node

    def remove_task(self, index: int) -> bool:
        if 0 <= index < len(self.todos):
            removed = self.todos.pop(index)
            logger.info(f"[PlanManager] Remove task: {removed.content}")
            return True
        return False

    def update_status(self, index: int, status: TaskStatus) -> bool:
        if 0 <= index < len(self.todos):
            self.todos[index].status = status
            logger.info(
                f"[PlanManager] Update task[{index}] -> {status.value}"
            )
            return True
        return False

    # ---------- 查询 ----------

    def get_next_pending(self) -> Optional[PlanNode]:
        """获取下一个待执行任务"""
        for task in self.todos:
            if task.status == TaskStatus.PENDING:
                return task
        return None

    def get_todos_json(self) -> str:
        """返回 todos 的 JSON 字符串表示，便于存储或传输"""
        return json.dumps(self.get_todos(), ensure_ascii=False, indent=2)
    def get_all(self) -> List[PlanNode]:
        return self.todos

    def get_todos(self) -> List[Dict[str, Any]]:
        """给 TodoTool / Agent 用"""
        return [t.to_todo_dict() for t in self.todos]

    # ---------- Agent 同步 ----------

    def sync_from_todos(self, todos: List[Dict[str, Any]]) -> None:
        """
        从 Agent 生成的 todo 列表同步
        todo: [{"content": str, "status": str}]
        """
        self.todos.clear()
        for idx, item in enumerate(todos):
            node = PlanNode(
                node_id=f"task_{idx}",
                content=item.get("content", ""),
                status=TaskStatus(item.get("status", "pending")),
            )
            self.todos.append(node)

        logger.info(f"[PlanManager] Sync {len(self.todos)} todos")

    # ---------- 统计 ----------

    def summary(self) -> Dict[str, Any]:
        total = len(self.todos)
        completed = sum(1 for t in self.todos if t.status == TaskStatus.COMPLETED)

        return {
            "total": total,
            "completed": completed,
            "progress": completed / total if total else 0.0,
        }
