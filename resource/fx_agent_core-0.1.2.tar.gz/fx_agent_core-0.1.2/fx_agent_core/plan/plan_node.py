"""
PlanNode: 表示plan中的节点
"""

from dataclasses import dataclass
from typing import Dict, Any
from enum import Enum


class TaskStatus(str, Enum):
    """任务状态枚举"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class PlanNode:
    """
    Plan节点，表示一个任务单元
    """
    
    node_id: str  # 节点唯一标识
    content: str  # 任务描述
    status: TaskStatus = TaskStatus.PENDING  # 任务状态
    
    def to_todo_dict(self) -> Dict[str, Any]:
        """
        转换为TodoTool需要的格式
        
        Returns:
            dict: {"content": str, "status": str}
        """
        return {
            "content": self.content,
            "status": self.status.value,
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "node_id": self.node_id,
            "content": self.content,
            "status": self.status.value,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PlanNode":
        """从字典创建PlanNode"""
        return cls(
            node_id=data["node_id"],
            content=data["content"],
            status=TaskStatus(data.get("status", "pending")),
        )

