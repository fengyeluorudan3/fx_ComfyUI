from fx_lang_ex.utils.log_utils import logger, AgentLog
from fx_lang_ex.tools.fx_tool import BATool
from fx_agent_core.messages import AgentRequest, AgentResponse
from fx_agent_core.agents import AgentTemplates
from fx_agent_core.channel import SolutionResultStreamWriter
from fx_agent_core.resources import ResourceManager
from fx_agent_core.plan import PlanManager
from fx_lang_ex.constant import *


"""
BA AGENT逻辑主入口
Provides methods for creating agents, running prompts, and managing resources.
"""

class FxAgent:
    """
    A mock agent class similar to LangChain's agent functionality.
    Provides methods for creating agents, running prompts, and managing resources.
    """

    def __init__(self):
        logger.info("[*] [init] init agent service ...")

        # 上下文资源中心
        self.resources = ResourceManager()
        # 输出通道
        self.channel = SolutionResultStreamWriter()
        
        # Plan管理器（用于管理任务规划和todo列表，内存中管理）
        self.plan_manager = PlanManager()

        self.tools = None
        self.mock_agent = None
        self._agent = None

        logger.info("[*] [init] init agent service successfully!")

    def init(self, model_infos: dict, agent_infos: dict, tools: list[BATool], **kwargs):
        logger.info("[*] [init] init agent service ...")

        # agent主体
        self._agent = AgentTemplates.config_agent_templates(model_infos, agent_infos)

        self.tools = tools
        logger.info("[*] [init] init agent service successfully!")

    async def run(self, context: dict):
        """
        agent的核心逻辑，逐步调用请求+历史上下文+工具逻辑返回agentresponse
        """
        if not self._agent:
            msg = "请先调用 init 初始化 Agent实例"
            logger.error(f"[*] [main] agent_init_error: %s" % context["traceId"])
            agent_response = AgentResponse.from_error_code(0, msg)
            await self.channel.write(agent_response.to_dict())
            await self.channel.complete()
            return

        try:
            # 1. 解析请求拼接成agent需要的请求，初始化agent返回对象
            logger.info("[*] [main] ba agent request: %s" %
                        AgentLog.from_copilot_request(context).log_content)
            code, msg, agent_request = AgentRequest.from_copilot_request(context, self.resources)

            if code != 0:
                logger.error("[*] [main] parse copilot request failed: %s" % msg)
                agent_response = AgentResponse.from_error_code(code, msg)
                await self.channel.write(agent_response.to_dict())
                await self.channel.complete()
                return

            # 根据传入的上下文
            if context.get("mock"):
                await self.mock_agent.process(
                    agent_request,
                    stream_writer=self.channel,
                    tools=self.tools,
                    resources=self.resources
                )
                return

            logger.info("[*] [main] start agent processing: %s" %
                        AgentLog.from_kv(traceId=context.get("ba_context", "")).log_content)

            await self._agent.process(
                stream_writer=self.channel,
                agent_request=agent_request,
                resources=self.resources,
                plan_manager=self.plan_manager,
                tools=self.tools,
            )

            logger.info("[*] [main] agent processing complete: %s" %
                        AgentLog.from_kv(traceId=context.get("ba_context", "")).log_content)

        except Exception as e:
            logger.error(f"[*] [main] process failed: %s" % str(e.with_traceback()))
            agent_response = AgentResponse.from_error_code(ResponseCode.SERVER_ERROR.code, str(e))
            await self.channel.write(agent_response.to_dict())
            await self.channel.complete()

    # ---------------- Resource 操作逻辑 ----------------
    def add_resource(self, resource_type: str, resource_data: dict) -> str:
        """
        添加一个资源到 ResourceCenter.

        Args:
            resource_type (str): 资源类型 (如 "image", "video")
            resource_data (dict): 资源数据 (必须包含 id, type, url 等字段)

        Returns:
            str: 资源 ID
        """
        return self.resources.add_resource(resource_type, resource_data)

    def get_resource(self, resource_id: str) -> dict:
        """
        根据资源 ID 获取资源.

        Args:
            resource_id (str): 资源 ID

        Returns:
            dict: 资源数据
        """
        return self.resources.get_resource(resource_id)

    def get_all_resource(self, resource_type: str, resource_id: str) -> dict:
        """
        根据资源类型获取资源.

        Args:
            resource_type (str): 资源类型.
            resource_id (str): 资源 ID.

        Returns:
            dict: 资源数据
        """
        return self.resources.resources
    
    # ---------------- Plan 操作逻辑 ----------------
    def get_todos(self) -> list[dict]:
        """
        获取当前agent运行的todo列表.

        Returns:
            list[dict]: todo列表，格式为 [{"content": str, "status": str}, ...]
        """
        return self.plan_manager.get_todos()
    
    def get_plan_summary(self) -> dict:
        """
        获取plan摘要信息.

        Returns:
            dict: 包含统计信息的字典
        """
        return self.plan_manager.get_plan_summary()
    
    def get_plan_manager(self) -> PlanManager:
        """
        获取PlanManager实例，用于高级操作.

        Returns:
            PlanManager: PlanManager实例
        """
        return self.plan_manager
