# -*- coding:utf-8 -*-
import json
import aiohttp
from typing import Optional, List, Any
from fx_lang_ex.utils.log_utils import logger
from fx_lang_ex.exception import RetryableException
from fx_lang_ex.utils.retry_utils import retry_on_retryable_exception


class MultiModelDoubaoChatModel:
    """
    Doubao Chat Model，对接火山引擎 Doubao API
    """

    def __init__(self, conf: dict = None):
        """
        初始化 DoubaoChatModel
        
        Args:
            conf: 配置字典，支持 key：
                - api_key: API密钥（必传，用于 Authorization Bearer）
                - api_endpoint: 接口地址（默认使用火山引擎地址）
                - model_name: 模型名（默认 doubao-seed-1-6-251015）
                - max_completion_tokens: 最大完成token数（默认 65535）
                - temperature: 温度参数（默认 0.7）
        """
        self.conf = conf or {}
        self.api_key = self.conf.get("api_key", "5d7a2b03-bfdb-47a1-bc7e-68a2b43b0fa3")
        self.api_endpoint = self.conf.get(
            "api_endpoint", 
            "https://ark.cn-beijing.volces.com/api/v3/chat/completions"
        )
        self.model_name = self.conf.get("model_name", "doubao-seed-1-6-251015")
        self.max_completion_tokens = self.conf.get("max_completion_tokens", 65535)
        self.temperature = self.conf.get("temperature", 0.7)
        
        if not self.api_key:
            logger.warning("[*] [chat_model] Doubao API key not provided")
        
        logger.info(f"[*] [chat_model] EgressMultiModelChatModel_init: model={self.model_name}, endpoint={self.api_endpoint}")

    @retry_on_retryable_exception(delays=(5, 10, 20))
    async def generate(self, messages: list, resources: list = None, **kwargs):
        """
        异步生成方法（对接火山引擎 Doubao API，流式响应）
        
        Args:
            messages: 消息列表
            resources: 资源列表（图片等）
            **kwargs: 其他参数
            
        Yields:
            str: 每个分片内容（chunk）
        """
        resources = resources or []
        
        # 处理多模态消息（图片资源）
        processed_messages = self._process_messages(messages, resources)
        
        # 构建请求体
        request_body = {
            "model": self.model_name,
            "max_completion_tokens": self.max_completion_tokens,
            "thinking": {"type": "disabled"},
            "messages": processed_messages,
            "stream": True,
        }
        
        # 如果配置了 temperature，添加到请求体
        if self.temperature is not None:
            request_body["temperature"] = self.temperature
        
        # 构建请求头
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        
        logger.info(f"[*] [chat_model] Doubao request: {json.dumps(request_body, ensure_ascii=False, indent=2)}")
        
        # 创建 aiohttp session
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    url=self.api_endpoint,
                    headers=headers,
                    json=request_body,
                    timeout=aiohttp.ClientTimeout(total=3600)
                ) as resp:
                    if resp.status != 200:
                        error_text = await resp.text()
                        logger.error(f"[*] [chat_model] Doubao API error: status={resp.status}, response={error_text}")
                        err_msg = f"接口错误: {resp.status}, 响应: {error_text}"
                        if resp.status in (502, 503, 504):
                            raise RetryableException(err_msg)
                        raise Exception(err_msg)
                    
                    # 处理流式响应（SSE 格式）
                    buffer = ""
                    async for chunk in resp.content.iter_any():
                        if not chunk:
                            continue
                        
                        try:
                            # 将 chunk 解码并添加到缓冲区
                            buffer += chunk.decode("utf-8", errors="replace")
                            
                            # 按行处理（SSE 格式是逐行发送的）
                            while "\n" in buffer:
                                line, buffer = buffer.split("\n", 1)
                                line = line.strip()
                                
                                if not line:
                                    continue
                                
                                # 处理 SSE 格式：data: {...}
                                if line.startswith("data:"):
                                    data_content = line[5:].strip()
                                    
                                    # 检查是否是结束标志
                                    if data_content == "[DONE]":
                                        yield "__STREAM_END__"
                                        return
                                    
                                    if data_content:
                                        try:
                                            event_data = json.loads(data_content)
                                            
                                            # 检查是否有错误
                                            if "error" in event_data:
                                                error_info = event_data["error"]
                                                error_code = error_info.get("code")
                                                error_message = error_info.get("message", "未知错误")
                                                
                                                logger.error(f"[*] [chat_model] Doubao API error: code={error_code}, message={error_message}")
                                                
                                                # 某些错误可以重试
                                                if error_code in (429, 500, 502, 503, 504):
                                                    raise RetryableException(f"API错误: {error_code}, {error_message}")
                                                raise Exception(f"API错误: {error_code}, {error_message}")
                                            
                                            # 提取 delta content
                                            choices = event_data.get("choices", [])
                                            if choices:
                                                choice = choices[0]
                                                delta = choice.get("delta", {})
                                                content = delta.get("content", "")
                                                
                                                # 检查是否结束
                                                finish_reason = choice.get("finish_reason")
                                                if finish_reason == "stop":
                                                    yield "_STREAM_END_"
                                                    return
                                                
                                                # 只 yield 非空内容
                                                if content:
                                                    yield content
                                            
                                        except json.JSONDecodeError as e:
                                            logger.warning(f"[*] [chat_model] Failed to parse JSON: {data_content}, error: {e}")
                                            continue
                                
                                # 处理非 SSE 格式的 JSON 响应（某些情况下可能直接返回 JSON）
                                elif line.startswith("{"):
                                    try:
                                        event_data = json.loads(line)
                                        if "error" in event_data:
                                            error_info = event_data["error"]
                                            error_code = error_info.get("code")
                                            error_message = error_info.get("message", "未知错误")
                                            raise Exception(f"API错误: {error_code}, {error_message}")
                                    except json.JSONDecodeError:
                                        pass
                        
                        except UnicodeDecodeError as e:
                            logger.warning(f"[*] [chat_model] Failed to decode chunk: {e}")
                            continue
                    
                    # 处理缓冲区中剩余的数据
                    if buffer.strip():
                        if buffer.strip().startswith("data:"):
                            data_content = buffer.strip()[5:].strip()
                            if data_content and data_content != "[DONE]":
                                try:
                                    event_data = json.loads(data_content)
                                    choices = event_data.get("choices", [])
                                    if choices:
                                        choice = choices[0]
                                        delta = choice.get("delta", {})
                                        content = delta.get("content", "")
                                        
                                        # 检查是否结束
                                        finish_reason = choice.get("finish_reason")
                                        if finish_reason == "stop":
                                            yield "_STREAM_END_"
                                            return
                                        
                                        # 只 yield 非空内容
                                        if content:
                                            yield content
                                except json.JSONDecodeError:
                                    pass
                    
                    # 流结束，发送结束标志
                    yield "_STREAM_END_"
            
            except ConnectionResetError as e:
                logger.exception(f"Connection reset by peer (可重试): {e}")
                raise RetryableException(f"Connection reset by peer: {e}")
            except aiohttp.ClientError as e:
                logger.exception(f"HTTP client error (可重试): {e}")
                raise RetryableException(f"HTTP client error: {e}")
            except Exception as e:
                logger.exception(f"Error while generating response: {e}")
                raise e

    def _process_messages(self, messages: list, resources: list) -> list:
        """
        处理消息和资源，构建多模态消息格式
        
        Args:
            messages: 原始消息列表
            resources: 资源列表（图片等）
            
        Returns:
            list: 处理后的消息列表，确保 content 始终是列表格式
        """
        processed_messages = []
        image_contents = []
        
        # 处理图片资源
        for res in resources:
            if res.get("type") == "image":
                store_id = res.get("store_id") or res.get("url")
                if store_id:
                    image_contents.append({
                        "type": "image_url",
                        "image_url": {
                            "url": store_id
                        }
                    })
        
        # 处理消息，确保格式统一
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            
            # 构建标准化的消息格式
            if isinstance(content, list):
                # 已经是列表格式
                multimodal_content = content.copy()
            elif isinstance(content, str):
                # 字符串格式，转换为列表格式
                multimodal_content = [{
                    "type": "text",
                    "text": content
                }]
            else:
                # 其他格式，转换为空列表
                multimodal_content = []
            
            # 如果是用户消息且有图片资源，合并图片
            if role == "user" and image_contents:
                # 检查是否已有图片
                has_image = any(
                    item.get("type") == "image_url" 
                    for item in multimodal_content 
                    if isinstance(item, dict)
                )
                
                if not has_image:
                    # 没有图片，添加图片资源到开头
                    multimodal_content = image_contents + multimodal_content
                    # 清空 image_contents，避免重复添加
                    image_contents = []
            
            # 添加处理后的消息
            processed_messages.append({
                "role": role,
                "content": multimodal_content
            })
        
        # 如果还有未处理的图片资源，创建一个新的用户消息
        if image_contents:
            processed_messages.insert(0, {
                "role": "user",
                "content": image_contents
            })
        
        return processed_messages

    async def close(self):
        """
        关闭连接（如果需要）
        """
        logger.info("[*] [chat_model] Doubao client closed")
