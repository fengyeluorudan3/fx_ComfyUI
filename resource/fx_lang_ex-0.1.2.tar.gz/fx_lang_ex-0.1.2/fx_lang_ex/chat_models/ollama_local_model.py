# -*- coding:utf-8 -*-
import json
from typing import Callable
from fx_lang_ex.utils.log_utils import logger
from fx_lang_ex.exception import RetryableException
from fx_lang_ex.utils.retry_utils import retry_on_retryable_exception
from ollama import Client
import requests

class EgressMultiModelChatModel:
    """
    基于 Ollama 的 Chat Model（使用官方客户端 ollama.Client）
    """

    def __init__(self, conf: dict = None):
        """
        初始化 Ollama 客户端
        """
        self.conf = conf or {}
        self.model_name = self.conf.get("model_name", "qwen2.5:14b")
        self.api_host = self.conf.get("host", "http://localhost:11434")
        self.client = Client(host=self.api_host)
        self.api_url = f"{self.api_host}/api/chat"
        logger.info(f"[*] [init] Ollama Client initialized: model={self.model_name}, host={self.api_host}")

    @retry_on_retryable_exception(delays=[5, 10, 20])
    async def generate(self, messages: list, resources: list = None, **kwargs):
        """
        使用 Ollama 官方客户端进行流式生成（去重重复 token）
        """
        # --- 格式规范化 ---
        # if isinstance(messages, str):
        #     messages = [{"role": "user", "content": messages}]
        # elif isinstance(messages, list) and isinstance(messages[0], dict):
        #     if isinstance(messages[0].get("content"), list):
        #         text = messages[0]["content"][0].get("text", "")
        #         messages = [{"role": "user", "content": text}]
        # else:
        #     raise ValueError("messages 参数格式不正确，必须为 str 或 list[dict]")

        logger.info(f"[*] [Ollama] 请求体: {json.dumps({'model': self.model_name, 'messages': messages}, ensure_ascii=False, indent=2)}")

        try:
            # stream = self.client.chat(
            #     model=self.model_name,
            #     messages=messages,
            #     stream=True,
            # )

            payload = {
                "model": self.model_name,
                "messages": messages,
                "stream": True,  # 流式输出
            }

            response = requests.post(
                self.api_url,
                json=payload,
                headers={"Content-Type": "application/json"},
                stream=True,  # 关键: requests 的流式接收
                timeout=60,  # 超时时间
            )
            response.raise_for_status()

            last_output = ""  # 🔹保存上次累计的完整内容
            # for chunk in stream:
            for line in response.iter_lines():
                if not line:
                    continue
                chunk = json.loads(line.decode("utf-8"))
                message = chunk.get("message", {})
                content = message.get("content", "")

                # Ollama 有时每次返回都是整个累计内容
                if content and content != last_output:
                    # 只输出新差异部分
                    if content:
                        yield content
                    last_output = content

                if chunk.get("done"):
                    yield "_STREAM_END_"
                    break

        except Exception as e:
            logger.error(f"[*] [Ollama] 推理时发生错误: {e}")
            raise e

    async def close(self):
        """
        Ollama Client 是同步的，不需要 async close
        """
        logger.info("[*] [Ollama] Client closed (no-op for sync client)")
