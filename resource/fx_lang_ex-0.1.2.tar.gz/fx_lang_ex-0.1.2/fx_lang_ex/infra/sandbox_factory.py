"""
沙箱工厂 - 用于创建和管理不同类型的沙箱后端

提供统一的接口来创建 Modal、Runloop 等云沙箱。
"""

from __future__ import annotations

from typing import Literal, Optional
import os

from fx_lang_ex.utils.protocal_utils import SandboxBackendProtocol

SandboxType = Literal["standalone", "modal", "runloop"]


def create_sandbox(
    sandbox_type: SandboxType = "standalone",
    **kwargs,
) -> SandboxBackendProtocol:
    """
    创建沙箱后端实例。
    
    Args:
        sandbox_type: 沙箱类型，支持 "standalone"、"modal"、"runloop"
        **kwargs: 传递给沙箱构造函数的额外参数
        
    Returns:
        沙箱后端实例
        
    Raises:
        ValueError: 如果沙箱类型不支持或缺少必要的依赖
        
    Examples:
        ```python
        # 创建本地沙箱（用于测试）
        backend = create_sandbox("standalone", root_dir="/tmp/test")
        
        # 创建 Modal 沙箱
        import modal
        app = modal.App("my-app")
        with app.run():
            sandbox = modal.Sandbox.create(app=app, workdir="/workspace")
            backend = create_sandbox("modal", sandbox=sandbox)
        
        # 创建 Runloop 沙箱
        from runloop_api_client import Runloop
        client = Runloop()
        devbox = client.devboxes.create()
        backend = create_sandbox("runloop", client=client, devbox_id=devbox.id)
        ```
    """
    if sandbox_type == "standalone":
        from fx_lang_ex.infra.standalone_backend import StandaloneFilesystemBackend

        root_dir = kwargs.get("root_dir", os.getcwd())
        enable_execution = kwargs.get("enable_execution", False)
        timeout = kwargs.get("timeout", 30)

        return StandaloneFilesystemBackend(
            root_path=root_dir,
            enable_execution=enable_execution,
        )

    elif sandbox_type == "modal":
        try:
            from fx_lang_ex.infra.modal_backend import ModalSandboxBackend
        except ImportError:
            raise ValueError(
                "Modal backend requires 'modal' package. "
                "Install it with: pip install modal"
            )
        
        sandbox = kwargs.get("sandbox")
        if sandbox is None:
            raise ValueError("Modal backend requires 'sandbox' parameter")
        
        timeout = kwargs.get("timeout", 30 * 60)
        return ModalSandboxBackend(sandbox=sandbox, timeout=timeout)
    
    elif sandbox_type == "runloop":
        try:
            from fx_lang_ex.infra.runloop_backend import RunloopSandboxBackend
        except ImportError:
            raise ValueError(
                "Runloop backend requires 'runloop-api-client' package. "
                "Install it with: pip install runloop-api-client"
            )
        
        client = kwargs.get("client")
        devbox_id = kwargs.get("devbox_id")
        
        if client is None or devbox_id is None:
            raise ValueError(
                "Runloop backend requires 'client' and 'devbox_id' parameters"
            )
        
        return RunloopSandboxBackend(client=client, devbox_id=devbox_id)
    
    else:
        raise ValueError(
            f"Unsupported sandbox type: {sandbox_type}. "
            f"Supported types: standalone, modal, runloop"
        )


async def create_modal_sandbox_async(
    app_name: str = "fx-lang-ex-sandbox",
    workdir: str = "/workspace",
    timeout: int = 30 * 60,
) -> SandboxBackendProtocol:
    """
    异步创建并初始化 Modal 沙箱。
    
    这是一个便捷方法，自动处理 Modal 应用创建和沙箱启动。
    
    Args:
        app_name: Modal 应用名称
        workdir: 沙箱工作目录
        timeout: 命令执行超时时间（秒）
        
    Returns:
        已初始化的 Modal 沙箱后端
        
    Raises:
        ImportError: 如果未安装 modal 包
        
    Examples:
        ```python
        import asyncio
        
        async def main():
            backend = await create_modal_sandbox_async()
            
            from fx_lang_ex.tools.default import ExecuteTool
            tool = ExecuteTool(backend=backend)
            result = tool._run(command="echo Hello from Modal!")
            print(result)
        
        asyncio.run(main())
        ```
    """
    try:
        import modal
    except ImportError:
        raise ImportError(
            "Modal backend requires 'modal' package. "
            "Install it with: pip install modal"
        )
    
    # 创建 Modal 应用
    app = modal.App(app_name)
    
    # 在应用上下文中创建沙箱
    async with app.run():
        sandbox = modal.Sandbox.create(
            app=app,
            workdir=workdir,
        )
        
        # 等待沙箱就绪（简单的健康检查）
        try:
            process = sandbox.exec("echo", "ready")
            process.wait()
        except Exception as e:
            raise RuntimeError(f"Failed to initialize Modal sandbox: {e}")
        
        return create_sandbox("modal", sandbox=sandbox, timeout=timeout)


def create_runloop_sandbox(
    api_key: Optional[str] = None,
    blueprint_name: str = "ubuntu",
    blueprint_id: Optional[str] = None,
) -> SandboxBackendProtocol:
    """
    创建并初始化 Runloop devbox 沙箱。
    
    这是一个便捷方法，自动处理 Runloop 客户端创建和 devbox 启动。
    
    Args:
        api_key: Runloop API 密钥（如果未提供，从 RUNLOOP_API_KEY 环境变量读取）
        blueprint_name: Devbox 模板名称
        blueprint_id: Devbox 模板 ID（如果提供，会覆盖 blueprint_name）

    Returns:
        已初始化的 Runloop 沙箱后端
        
    Raises:
        ImportError: 如果未安装 runloop-api-client 包
        ValueError: 如果未提供 API 密钥
        
    Examples:
        ```python
        # 使用环境变量中的 API 密钥
        backend = create_runloop_sandbox()
        
        # 或者显式提供 API 密钥
        backend = create_runloop_sandbox(api_key="your-api-key")
        
        # 使用工具
        from fx_lang_ex.tools.default import ExecuteTool
        tool = ExecuteTool(backend=backend)
        result = tool._run(command="echo Hello from Runloop!")
        print(result)
        ```
    """
    try:
        from runloop_api_client import Runloop
    except ImportError:
        raise ImportError(
            "Runloop backend requires 'runloop-api-client' package. "
            "Install it with: pip install runloop-api-client"
        )
    
    # 获取 API 密钥
    if api_key is None:
        api_key = os.environ.get("RUNLOOP_API_KEY")
        if api_key is None:
            raise ValueError(
                "Runloop API key not found. "
                "Either pass 'api_key' parameter or set RUNLOOP_API_KEY environment variable."
            )
    
    # 创建 Runloop 客户端
    client = Runloop(api_key=api_key)
    
    # 创建 devbox
    create_params = {}
    if blueprint_id:
        create_params["blueprint_id"] = blueprint_id
    else:
        create_params["blueprint_name"] = blueprint_name
    
    devbox = client.devboxes.create(**create_params)
    
    # 等待 devbox 就绪（轮询状态）
    import time
    max_wait = 60  # 最多等待 60 秒
    start_time = time.time()
    
    while time.time() - start_time < max_wait:
        status = client.devboxes.retrieve(id=devbox.id)
        if status.status == "running":
            break
        time.sleep(2)
    else:
        raise RuntimeError(f"Runloop devbox {devbox.id} failed to start within {max_wait}s")
    
    return create_sandbox("runloop", client=client, devbox_id=devbox.id)
