"""
Standalone filesystem backend for independent tool testing.

This backend doesn't require LangGraph or agent state.
"""

import os
import glob as glob_module
import re
import subprocess
import json
from pathlib import Path
from typing import Any, Dict, List

from fx_lang_ex.utils.protocal_utils import (
    BackendProtocol,
    SandboxBackendProtocol,
    EditResult,
    ExecuteResponse,
    FileInfo,
    GrepMatch,
    WriteResult,
    FileDownloadResponse,
    FileUploadResponse,
)


class StandaloneFilesystemBackend(SandboxBackendProtocol):
    """
    独立文件系统后端，用于本地文件操作测试。
    
    支持文件操作和命令执行（在本地环境中运行，请注意安全性）。
    不依赖 agent state 或 runtime，可以独立使用。
    """

    def __init__(self, root_path: str = ".", enable_execution: bool = True):
        """
        初始化文件系统后端。
        
        Args:
            root_path: 根路径，所有操作都相对于此路径
            enable_execution: 是否启用命令执行功能（默认True）
        """
        self.root_path = Path(root_path).resolve()
        if not self.root_path.exists():
            self.root_path.mkdir(parents=True, exist_ok=True)
        
        self.enable_execution = enable_execution
        self._sandbox_id = f"standalone_{id(self)}"

    def _resolve_path(self, path: str) -> Path:
        """
        解析路径到绝对路径。
        
        Args:
            path: 输入路径（以 / 开头的虚拟绝对路径）
            
        Returns:
            解析后的实际文件系统路径
        """
        # 移除开头的 /，因为我们使用 root_path
        path = path.lstrip("/")
        resolved = (self.root_path / path).resolve()
        
        # 安全检查：确保路径在 root_path 内
        try:
            resolved.relative_to(self.root_path)
        except ValueError:
            raise PermissionError(f"Path outside root: {path}")
        
        return resolved

    def ls_info(self, path: str) -> List[FileInfo]:
        """列出目录内容。"""
        resolved = self._resolve_path(path)
        
        if not resolved.exists():
            return []
        
        if not resolved.is_dir():
            return []
        
        results = []
        try:
            for item in resolved.iterdir():
                # 返回相对于当前路径的名称
                results.append({
                    "path": item.name,
                    "is_dir": item.is_dir(),
                })
        except PermissionError:
            pass
        
        return results

    def read(self, file_path: str, offset: int = 0, limit: int = 500) -> str:
        """读取文件内容。"""
        resolved = self._resolve_path(file_path)
        
        if not resolved.exists():
            return "file_not_found"
        
        if resolved.is_dir():
            return "is_directory"
        
        try:
            with open(resolved, "r", encoding="utf-8") as f:
                lines = f.readlines()
            
            # 应用偏移和限制
            selected_lines = lines[offset:offset + limit]
            
            # 添加行号
            numbered_lines = [
                f"{offset + i + 1:6d} | {line.rstrip()}"
                for i, line in enumerate(selected_lines)
            ]
            
            return "\n".join(numbered_lines)
        except UnicodeDecodeError:
            return "Error: File is not UTF-8 encoded"
        except Exception as e:
            return f"Error reading file: {str(e)}"

    def write(self, file_path: str, content: str) -> WriteResult:
        """写入文件内容。"""
        resolved = self._resolve_path(file_path)
        
        if resolved.exists():
            return WriteResult(
                error="file_already_exists",
                path=None,
                files_update=None,
            )
        
        try:
            # 创建父目录
            resolved.parent.mkdir(parents=True, exist_ok=True)
            
            # 写入文件
            with open(resolved, "w", encoding="utf-8") as f:
                f.write(content)
            
            return WriteResult(
                error=None,
                path=file_path,
                files_update=None,
            )
        except Exception as e:
            return WriteResult(
                error=f"write_failed: {str(e)}",
                path=None,
                files_update=None,
            )

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        """编辑文件内容。"""
        resolved = self._resolve_path(file_path)
        
        if not resolved.exists():
            return EditResult(
                error="file_not_found",
                path=None,
                files_update=None,
                occurrences=None,
            )
        
        try:
            with open(resolved, "r", encoding="utf-8") as f:
                content = f.read()
            
            # 计算替换次数
            count = content.count(old_string)
            
            if count == 0:
                return EditResult(
                    error="string_not_found",
                    path=None,
                    files_update=None,
                    occurrences=0,
                )
            
            if count > 1 and not replace_all:
                return EditResult(
                    error="multiple_matches",
                    path=None,
                    files_update=None,
                    occurrences=count,
                )
            
            # 执行替换
            if replace_all:
                new_content = content.replace(old_string, new_string)
                replacements = count
            else:
                new_content = content.replace(old_string, new_string, 1)
                replacements = 1
            
            # 写回文件
            with open(resolved, "w", encoding="utf-8") as f:
                f.write(new_content)
            
            return EditResult(
                error=None,
                path=file_path,
                files_update=None,
                occurrences=replacements,
            )
        except Exception as e:
            return EditResult(
                error=f"edit_failed: {str(e)}",
                path=None,
                files_update=None,
                occurrences=None,
            )

    def glob_info(self, pattern: str, path: str = "/") -> List[FileInfo]:
        """使用 glob 模式搜索文件。"""
        resolved_path = self._resolve_path(path)
        
        try:
            # 构建完整的 glob 模式
            full_pattern = str(resolved_path / pattern.lstrip("/"))
            matches = glob_module.glob(full_pattern, recursive=True)
            
            results = []
            for match in matches:
                match_path = Path(match)
                # 返回相对于 root_path 的路径
                try:
                    rel_path = match_path.relative_to(self.root_path)
                    results.append({
                        "path": "/" + str(rel_path).replace("\\", "/"),
                        "is_dir": match_path.is_dir(),
                    })
                except ValueError:
                    continue
            
            return results
        except Exception:
            return []

    def grep_raw(
        self,
        pattern: str,
        path: str | None = None,
        glob: str | None = None,
    ) -> List[GrepMatch] | str:
        """搜索文件内容。"""
        if path is None:
            path = "/"
        if glob is None:
            glob = "**/*"
            
        resolved_path = self._resolve_path(path)
        
        try:
            # 编译正则表达式
            regex = re.compile(pattern)
        except re.error as e:
            return f"Invalid regex pattern: {str(e)}"
        
        try:
            # 获取匹配的文件
            glob_pattern = str(resolved_path / glob.lstrip("/"))
            files = glob_module.glob(glob_pattern, recursive=True)
            
            results = []
            for file_path in files:
                file_obj = Path(file_path)
                
                # 跳过目录
                if file_obj.is_dir():
                    continue
                
                try:
                    with open(file_obj, "r", encoding="utf-8") as f:
                        lines = f.readlines()
                    
                    # 搜索匹配行
                    for line_num, line in enumerate(lines, 1):
                        if regex.search(line):
                            # 返回相对路径
                            try:
                                rel_path = file_obj.relative_to(self.root_path)
                                results.append({
                                    "path": "/" + str(rel_path).replace("\\", "/"),
                                    "line": line_num,
                                    "text": line.rstrip(),
                                })
                            except ValueError:
                                continue
                except (UnicodeDecodeError, PermissionError):
                    continue
            
            return results
        except Exception as e:
            return f"Grep failed: {str(e)}"

    def upload_files(self, files: List[tuple[str, bytes]]) -> List[FileUploadResponse]:
        """上传文件（与 write 类似但接受 bytes）。"""
        responses = []
        for file_path, content in files:
            resolved = self._resolve_path(file_path)
            try:
                resolved.parent.mkdir(parents=True, exist_ok=True)
                with open(resolved, "wb") as f:
                    f.write(content)
                responses.append(FileUploadResponse(path=file_path, error=None))
            except Exception as e:
                responses.append(FileUploadResponse(
                    path=file_path,
                    error="permission_denied",  # type: ignore
                ))
        return responses

    def download_files(self, paths: List[str]) -> List[FileDownloadResponse]:
        """下载文件（读取为 bytes）。"""
        responses = []
        for file_path in paths:
            resolved = self._resolve_path(file_path)
            if not resolved.exists():
                responses.append(FileDownloadResponse(
                    path=file_path,
                    content=None,
                    error="file_not_found",
                ))
            elif resolved.is_dir():
                responses.append(FileDownloadResponse(
                    path=file_path,
                    content=None,
                    error="is_directory",
                ))
            else:
                try:
                    with open(resolved, "rb") as f:
                        content = f.read()
                    responses.append(FileDownloadResponse(
                        path=file_path,
                        content=content,
                        error=None,
                    ))
                except Exception:
                    responses.append(FileDownloadResponse(
                        path=file_path,
                        content=None,
                        error="permission_denied",
                    ))
        return responses

    def execute(self, command: str) -> ExecuteResponse:
        """
        在本地环境中执行命令。
        
        ⚠️ 警告：命令在本地系统中直接执行，不在隔离环境中！
        请确保只在受信任的环境中使用此功能。
        
        Args:
            command: 要执行的 shell 命令
            
        Returns:
            ExecuteResponse 包含输出、退出码和截断标志
        """
        if not self.enable_execution:
            return ExecuteResponse(
                output="Error: Command execution is disabled for safety.\n"
                       "Set enable_execution=True when creating backend to enable.",
                exit_code=-1,
                truncated=False,
            )
        
        try:
            # 在 root_path 目录中执行命令
            result = subprocess.run(
                command,
                shell=True,
                cwd=str(self.root_path),
                capture_output=True,
                text=True,
                timeout=30,  # 30秒超时
            )
            
            # 合并 stdout 和 stderr
            output = result.stdout or ""
            if result.stderr:
                output += "\n" + result.stderr if output else result.stderr
            
            # 检查是否需要截断（超过 100KB）
            max_output_size = 100 * 1024
            truncated = len(output) > max_output_size
            if truncated:
                output = output[:max_output_size] + "\n... [output truncated]"
            
            return ExecuteResponse(
                output=output,
                exit_code=result.returncode,
                truncated=truncated,
            )
        
        except subprocess.TimeoutExpired:
            return ExecuteResponse(
                output="Error: Command execution timeout (30 seconds)",
                exit_code=-1,
                truncated=False,
            )
        except Exception as e:
            return ExecuteResponse(
                output=f"Error executing command: {str(e)}",
                exit_code=-1,
                truncated=False,
            )

    @property
    def id(self) -> str:
        """返回沙箱后端的唯一标识符。"""
        return self._sandbox_id
    
    def write_todos(self, todos: list[dict[str, Any]]) -> None:
        """
        将todo列表写入文件系统。
        
        Args:
            todos: todo列表，格式为 [{"content": str, "status": str}, ...]
        """
        todos_file = self.root_path / ".todos.json"
        try:
            with open(todos_file, "w", encoding="utf-8") as f:
                json.dump(todos, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"Failed to write todos: {e}")
    
    def get_todos(self) -> list[dict[str, Any]]:
        """
        从文件系统读取todo列表。
        
        Returns:
            todo列表，格式为 [{"content": str, "status": str}, ...]
        """
        todos_file = self.root_path / ".todos.json"
        try:
            if todos_file.exists():
                with open(todos_file, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            logger.warning(f"Failed to read todos: {e}")
        return []