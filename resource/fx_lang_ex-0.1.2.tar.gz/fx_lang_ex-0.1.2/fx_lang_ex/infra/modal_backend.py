"""
Modal 沙箱后端实现（参考 DeepAgent）

提供真正的隔离沙箱环境执行。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Any

from fx_lang_ex.utils.protocal_utils import (
    SandboxBackendProtocol,
    ExecuteResponse,
    FileDownloadResponse,
    FileUploadResponse,
    FileInfo,
    GrepMatch,
    WriteResult,
    EditResult,
)

if TYPE_CHECKING:
    import modal


class ModalSandboxBackend(SandboxBackendProtocol):
    """
    Modal 沙箱后端，提供真正的容器隔离环境。
    
    使用 Modal.com 的云沙箱服务来执行命令。
    
    安装要求:
        pip install modal
        
    使用方法:
        ```python
        import modal
        
        app = modal.App("my-sandbox")
        with app.run():
            sandbox = modal.Sandbox.create(app=app, workdir="/workspace")
            
            # 等待沙箱就绪
            # ... (见 DeepAgent 的 sandbox_factory.py)
            
            backend = ModalSandboxBackend(sandbox)
            
            # 使用工具
            from fx_lang_ex.tools.default import ExecuteTool
            tool = ExecuteTool(backend=backend)
            result = tool._run(command="echo Hello")
        ```
    """

    def __init__(self, sandbox: modal.Sandbox, timeout: int = 30 * 60) -> None:
        """
        初始化 Modal 沙箱后端。
        
        Args:
            sandbox: Modal Sandbox 实例
            timeout: 命令执行超时时间（秒），默认30分钟
        """
        self._sandbox = sandbox
        self._timeout = timeout

    @property
    def id(self) -> str:
        """返回沙箱的唯一标识符。"""
        return self._sandbox.object_id

    def execute(self, command: str) -> ExecuteResponse:
        """
        在 Modal 沙箱中执行命令。
        
        Args:
            command: 要执行的 shell 命令
            
        Returns:
            ExecuteResponse 包含输出、退出码和截断标志
        """
        # 使用 Modal 的 exec API 执行命令
        process = self._sandbox.exec("bash", "-c", command, timeout=self._timeout)
        
        # 等待进程完成
        process.wait()
        
        # 读取输出
        stdout = process.stdout.read() or ""
        stderr = process.stderr.read() or ""
        
        # 合并 stdout 和 stderr
        output = stdout
        if stderr:
            output += "\n" + stderr if output else stderr
        
        return ExecuteResponse(
            output=output,
            exit_code=process.returncode,
            truncated=False,  # Modal 不提供截断信息
        )

    # 以下方法通过执行 shell 命令实现文件操作
    # 参考 DeepAgent 的 BaseSandbox 实现
    
    def ls_info(self, path: str) -> List[FileInfo]:
        """通过执行命令列出目录内容。"""
        cmd = f"""python3 -c "
import os
import json

path = '{path}'
try:
    with os.scandir(path) as it:
        for entry in it:
            result = {{
                'path': entry.name,
                'is_dir': entry.is_dir(follow_symlinks=False)
            }}
            print(json.dumps(result))
except FileNotFoundError:
    pass
except PermissionError:
    pass
"
"""
        result = self.execute(cmd)
        infos = []
        if result.output:
            for line in result.output.strip().split('\n'):
                if line:
                    try:
                        import json
                        infos.append(json.loads(line))
                    except:
                        pass
        return infos

    def read(self, file_path: str, offset: int = 0, limit: int = 500) -> str:
        """通过执行命令读取文件。"""
        cmd = f"""python3 -c "
import sys
try:
    with open('{file_path}', 'r', encoding='utf-8') as f:
        lines = f.readlines()
    selected = lines[{offset}:{offset + limit}]
    for i, line in enumerate(selected):
        print(f'{{({offset} + i + 1):6d}} | {{line.rstrip()}}')
except FileNotFoundError:
    print('file_not_found')
except IsADirectoryError:
    print('is_directory')
except Exception as e:
    print(f'Error: {{e}}')
"
"""
        result = self.execute(cmd)
        return result.output

    def write(self, file_path: str, content: str) -> WriteResult:
        """通过执行命令写入文件。"""
        # 转义内容中的特殊字符
        import json
        escaped_content = json.dumps(content)
        
        cmd = f"""python3 -c "
import json
import os

file_path = '{file_path}'
content = json.loads({escaped_content})

if os.path.exists(file_path):
    print('file_already_exists')
else:
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print('success')
"
"""
        result = self.execute(cmd)
        
        if "file_already_exists" in result.output:
            return WriteResult(error="file_already_exists", path=None, files_update=None)
        elif "success" in result.output:
            return WriteResult(error=None, path=file_path, files_update=None)
        else:
            return WriteResult(error=result.output, path=None, files_update=None)

    def edit(
        self, 
        file_path: str, 
        old_string: str, 
        new_string: str, 
        replace_all: bool = False
    ) -> EditResult:
        """通过执行命令编辑文件。"""
        import json
        escaped_old = json.dumps(old_string)
        escaped_new = json.dumps(new_string)
        
        cmd = f"""python3 -c "
import json

file_path = '{file_path}'
old_string = json.loads({escaped_old})
new_string = json.loads({escaped_new})
replace_all = {str(replace_all)}

try:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    count = content.count(old_string)
    if count == 0:
        print('string_not_found|0')
    elif count > 1 and not replace_all:
        print(f'multiple_matches|{{count}}')
    else:
        if replace_all:
            new_content = content.replace(old_string, new_string)
            replacements = count
        else:
            new_content = content.replace(old_string, new_string, 1)
            replacements = 1
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f'success|{{replacements}}')
        
except FileNotFoundError:
    print('file_not_found|0')
except Exception as e:
    print(f'error|0|{{e}}')
"
"""
        result = self.execute(cmd)
        parts = result.output.strip().split('|')
        
        if parts[0] == 'success':
            return EditResult(
                error=None,
                path=file_path,
                files_update=None,
                occurrences=int(parts[1])
            )
        else:
            return EditResult(
                error=parts[0],
                path=None,
                files_update=None,
                occurrences=int(parts[1]) if len(parts) > 1 else 0
            )

    def glob_info(self, pattern: str, path: str = "/") -> List[FileInfo]:
        """通过执行命令进行 glob 匹配。"""
        cmd = f"""python3 -c "
import glob
import json
import os

pattern = '{path.rstrip('/')}/{pattern.lstrip('/')}'
matches = glob.glob(pattern, recursive=True)

for match in matches:
    is_dir = os.path.isdir(match)
    print(json.dumps({{'path': match, 'is_dir': is_dir}}))
"
"""
        result = self.execute(cmd)
        infos = []
        if result.output:
            for line in result.output.strip().split('\n'):
                if line:
                    try:
                        import json
                        infos.append(json.loads(line))
                    except:
                        pass
        return infos

    def grep_raw(
        self, 
        pattern: str, 
        path: str | None = None, 
        glob: str | None = None
    ) -> List[GrepMatch] | str:
        """通过执行命令进行文本搜索。"""
        if path is None:
            path = "/"
        if glob is None:
            glob = "**/*"
        
        import json
        escaped_pattern = json.dumps(pattern)
        
        cmd = f"""python3 -c "
import re
import glob as glob_module
import json

pattern = json.loads({escaped_pattern})
path = '{path}'
glob_pattern = '{glob}'

try:
    regex = re.compile(pattern)
except re.error as e:
    print(f'REGEX_ERROR:{{e}}')
    exit(1)

full_pattern = f'{{path.rstrip(\"/\")}}/{{glob_pattern.lstrip(\"/\")}}'
files = glob_module.glob(full_pattern, recursive=True)

for file_path in files:
    try:
        if not __import__('os').path.isfile(file_path):
            continue
        with open(file_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                if regex.search(line):
                    result = {{
                        'path': file_path,
                        'line': line_num,
                        'text': line.rstrip()
                    }}
                    print(json.dumps(result))
    except:
        pass
"
"""
        result = self.execute(cmd)
        
        if result.output.startswith('REGEX_ERROR:'):
            return result.output.replace('REGEX_ERROR:', 'Invalid regex: ')
        
        matches = []
        if result.output:
            for line in result.output.strip().split('\n'):
                if line:
                    try:
                        import json
                        matches.append(json.loads(line))
                    except:
                        pass
        return matches

    def upload_files(self, files: List[tuple[str, bytes]]) -> List[FileUploadResponse]:
        """上传文件到 Modal 沙箱。"""
        responses = []
        for path, content in files:
            try:
                with self._sandbox.open(path, "wb") as f:
                    f.write(content)
                responses.append(FileUploadResponse(path=path, error=None))
            except Exception:
                responses.append(FileUploadResponse(path=path, error="permission_denied"))  # type: ignore
        return responses

    def download_files(self, paths: List[str]) -> List[FileDownloadResponse]:
        """从 Modal 沙箱下载文件。"""
        responses = []
        for path in paths:
            try:
                with self._sandbox.open(path, "rb") as f:
                    content = f.read()
                responses.append(FileDownloadResponse(path=path, content=content, error=None))
            except FileNotFoundError:
                responses.append(FileDownloadResponse(path=path, content=None, error="file_not_found"))
            except Exception:
                responses.append(FileDownloadResponse(path=path, content=None, error="permission_denied"))
        return responses
