from typing import Any, Dict, Optional
from abc import ABC, abstractmethod


class BATool(ABC):
    """
    通用型 BA Tool 基类，统一规范工具的编写。
    """

    @abstractmethod
    def get_tool_schema(self) -> Dict[str, Any]:
        """
        必须由子类实现的工具定义 schema 返回 dict，示例：

        {
            "id": "tool_xxx",
            "name": "get_image_brightness",
            "api_domain": "获取图像亮度",
            "description": "获取图像平均亮度",
            "parameters": {...},
            "response": {...},
            "version": "v1.0.0",
        }
        """
        raise NotImplementedError("子类必须实现 get_tool_schema 方法")

    def _run(self, *args: Any, **kwargs: Any) -> Any:
        """
        同步执行方法。
        外部直接调用时默认执行此逻辑。
        """
        raise NotImplementedError("请在子类实现 _run 方法")

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        """
        异步执行方法。
        外部异步调用时默认执行此逻辑。
        """
        raise NotImplementedError("请在子类实现 _arun 方法")
