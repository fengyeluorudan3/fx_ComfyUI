"""Execute shell command tool implementation."""

from typing import Any, Dict, Optional


from fx_lang_ex.utils.protocal_utils  import BackendProtocol, SandboxBackendProtocol
from fx_lang_ex.tools import BATool

class ExecuteTool(BATool):
    """
    在沙箱环境中执行 Shell 命令。
    
    该工具仅在 backend 实现 SandboxBackendProtocol 时可用，提供安全的命令执行环境。
    """

    def __init__(self, backend: BackendProtocol):
        """
        初始化 ExecuteTool。
        
        Args:
            backend: 文件存储后端实例（必须实现 SandboxBackendProtocol 才能执行命令）
        """
        self.backend = backend
        self._supports_execution = self._check_execution_support()

    def _check_execution_support(self) -> bool:
        """
        检查后端是否支持命令执行。
        
        Returns:
            如果后端支持命令执行返回 True，否则返回 False
        """
        # 检查是否为 CompositeBackend
        from deepagents.backends.composite import CompositeBackend

        if isinstance(self.backend, CompositeBackend):
            return isinstance(self.backend.default, SandboxBackendProtocol)
        
        # 检查是否实现了 SandboxBackendProtocol
        return isinstance(self.backend, SandboxBackendProtocol)

    def get_tool_schema(self) -> Dict[str, Any]:
        """
        返回 execute 工具的 schema 定义。
        
        Returns:
            工具的完整定义，包括参数、描述等信息
        """
        return {
            "id": "tool_filesystem_execute",
            "name": "execute",
            "api_domain": "执行命令",
            "description": """Executes a given command in the sandbox environment with proper handling and security measures.

Before executing the command, please follow these steps:

1. Directory Verification:
   - If the command will create new directories or files, first use the ls tool to verify the parent directory exists and is the correct location
   - For example, before running "mkdir foo/bar", first use ls to check that "foo" exists and is the intended parent directory

2. Command Execution:
   - Always quote file paths that contain spaces with double quotes (e.g., cd "path with spaces/file.txt")
   - Examples of proper quoting:
     - cd "/Users/name/My Documents" (correct)
     - cd /Users/name/My Documents (incorrect - will fail)
     - python "/path/with spaces/script.py" (correct)
     - python /path/with spaces/script.py (incorrect - will fail)
   - After ensuring proper quoting, execute the command
   - Capture the output of the command

Usage notes:
  - The command parameter is required
  - Commands run in an isolated sandbox environment
  - Returns combined stdout/stderr output with exit code
  - If the output is very large, it may be truncated
  - VERY IMPORTANT: You MUST avoid using search commands like find and grep. Instead use the grep, glob tools to search. You MUST avoid read tools like cat, head, tail, and use read_file to read files.
  - When issuing multiple commands, use the ';' or '&&' operator to separate them. DO NOT use newlines (newlines are ok in quoted strings)
    - Use '&&' when commands depend on each other (e.g., "mkdir dir && cd dir")
    - Use ';' only when you need to run commands sequentially but don't care if earlier commands fail
  - Try to maintain your current working directory throughout the session by using absolute paths and avoiding usage of cd

Examples:
  Good examples:
    - execute(command="pytest /foo/bar/tests")
    - execute(command="python /path/to/script.py")
    - execute(command="npm install && npm test")

  Bad examples (avoid these):
    - execute(command="cd /foo/bar && pytest tests")  # Use absolute path instead
    - execute(command="cat file.txt")  # Use read_file tool instead
    - execute(command="find . -name '*.py'")  # Use glob tool instead
    - execute(command="grep -r 'pattern' .")  # Use grep tool instead

Note: This tool is only available if the backend supports execution (SandboxBackendProtocol).
If execution is not supported, the tool will return an error message.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The shell command to execute in the sandbox environment.",
                    },
                },
                "required": ["command"],
            },
            "response": {
                "type": "object",
                "properties": {
                    "output": {
                        "type": "string",
                        "description": "Combined stdout/stderr output from the command.",
                    },
                    "exit_code": {
                        "type": "integer",
                        "description": "Exit code of the command (0 for success).",
                    },
                    "truncated": {
                        "type": "boolean",
                        "description": "Whether the output was truncated due to size limits.",
                    },
                    "error": {
                        "type": "string",
                        "description": "Error message if execution is not supported or command failed.",
                    },
                },
            },
            "version": "v1.0.0",
        }

    def _run(self, command: str) -> Dict[str, Any]:
        """
        同步执行 Shell 命令。
        
        Args:
            command: 要执行的命令字符串
            
        Returns:
            包含输出、退出码、是否截断等信息的字典
        """
        # 检查是否支持执行
        if not self._supports_execution:
            return {
                "output": "",
                "exit_code": -1,
                "truncated": False,
                "error": (
                    "Error: Execution not available. This agent's backend "
                    "does not support command execution (SandboxBackendProtocol). "
                    "To use the execute tool, provide a backend that implements SandboxBackendProtocol."
                ),
            }
        
        try:
            # 执行命令
            result = self.backend.execute(command)  # type: ignore[union-attr]
            
            # 格式化输出
            parts = [result.output]
            
            if result.exit_code is not None:
                status = "succeeded" if result.exit_code == 0 else "failed"
                parts.append(f"\n[Command {status} with exit code {result.exit_code}]")
            
            if result.truncated:
                parts.append("\n[Output was truncated due to size limits]")
            
            return {
                "output": "".join(parts),
                "exit_code": result.exit_code or 0,
                "truncated": result.truncated,
                "error": None,
            }
        except NotImplementedError as e:
            return {
                "output": "",
                "exit_code": -1,
                "truncated": False,
                "error": f"Error: Execution not available. {e}",
            }
        except Exception as e:
            return {
                "output": "",
                "exit_code": -1,
                "truncated": False,
                "error": f"Error executing command: {str(e)}",
            }

    async def _arun(self, command: str) -> Dict[str, Any]:
        """
        异步执行 Shell 命令。
        
        Args:
            command: 要执行的命令字符串
            
        Returns:
            包含输出、退出码、是否截断等信息的字典
        """
        # 当前实现为同步调用，未来可以优化为真正的异步
        return self._run(command)
