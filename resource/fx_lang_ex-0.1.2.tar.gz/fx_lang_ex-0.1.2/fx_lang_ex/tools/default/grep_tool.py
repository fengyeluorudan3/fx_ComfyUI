"""Grep text search tool implementation."""

from typing import Any, Dict, Literal, Optional, Union

from fx_lang_ex.utils.protocal_utils import BackendProtocol
from fx_lang_ex.utils.tool_utils import truncate_if_too_long,format_grep_matches
from fx_lang_ex.tools import BATool



class GrepTool(BATool):
    """
    在文件中搜索文本模式。
    
    该工具支持在文件内容中搜索指定模式，并提供多种输出格式。
    """

    def __init__(self, backend: BackendProtocol):
        """
        初始化 GrepTool。
        
        Args:
            backend: 文件存储后端实例
        """
        self.backend = backend

    def get_tool_schema(self) -> Dict[str, Any]:
        """
        返回 grep 工具的 schema 定义。
        
        Returns:
            工具的完整定义，包括参数、描述等信息
        """
        return {
            "id": "tool_filesystem_grep",
            "name": "grep",
            "api_domain": "文本搜索",
            "description": """Search for a pattern in files.

Usage:
- The grep tool searches for text patterns across files
- The pattern parameter is the text to search for (literal string, not regex)
- The path parameter filters which directory to search in (default is the current working directory)
- The glob parameter accepts a glob pattern to filter which files to search (e.g., `*.py`)
- The output_mode parameter controls the output format:
  - `files_with_matches`: List only file paths containing matches (default)
  - `content`: Show matching lines with file path and line numbers
  - `count`: Show count of matches per file

Examples:
- Search all files: `grep(pattern="TODO")`
- Search Python files only: `grep(pattern="import", glob="*.py")`
- Show matching lines: `grep(pattern="error", output_mode="content")`""",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "The text pattern to search for (literal string, not regex).",
                    },
                    "path": {
                        "type": "string",
                        "description": "The directory path to search in. Default: None (searches from root)",
                        "default": None,
                    },
                    "glob": {
                        "type": "string",
                        "description": "Glob pattern to filter files (e.g., '*.py', '*.txt'). Default: None",
                        "default": None,
                    },
                    "output_mode": {
                        "type": "string",
                        "enum": ["files_with_matches", "content", "count"],
                        "description": "Output format: files_with_matches (default), content, or count",
                        "default": "files_with_matches",
                    },
                },
                "required": ["pattern"],
            },
            "response": {
                "type": "string",
                "description": "Search results in the specified format, or error message.",
            },
            "version": "v1.0.0",
        }

    def _run(
        self,
        pattern: str,
        path: Optional[str] = None,
        glob: Optional[str] = None,
        output_mode: Literal["files_with_matches", "content", "count"] = "files_with_matches",
    ) -> str:
        """
        同步执行 grep 文本搜索操作。
        
        Args:
            pattern: 要搜索的文本模式（字面字符串）
            path: 搜索目录路径（可选，默认从根目录搜索）
            glob: 文件过滤模式（可选，如 '*.py'）
            output_mode: 输出格式（files_with_matches/content/count）
            
        Returns:
            搜索结果字符串（格式由 output_mode 决定），或错误信息
        """
        try:
            # 执行 grep 搜索
            raw = self.backend.grep_raw(pattern, path=path, glob=glob)
            
            # 如果返回错误信息
            if isinstance(raw, str):
                return raw
            
            # 格式化搜索结果
            formatted = format_grep_matches(raw, output_mode)
            
            if not formatted:
                return f"No matches found for pattern: {pattern}"
            
            # 截断过长的输出
            return truncate_if_too_long(formatted)  # type: ignore[arg-type]
        except Exception as e:
            return f"Error searching with grep: {str(e)}"

    async def _arun(
        self,
        pattern: str,
        path: Optional[str] = None,
        glob: Optional[str] = None,
        output_mode: Literal["files_with_matches", "content", "count"] = "files_with_matches",
    ) -> str:
        """
        异步执行 grep 文本搜索操作。
        
        Args:
            pattern: 要搜索的文本模式（字面字符串）
            path: 搜索目录路径（可选，默认从根目录搜索）
            glob: 文件过滤模式（可选，如 '*.py'）
            output_mode: 输出格式（files_with_matches/content/count）
            
        Returns:
            搜索结果字符串（格式由 output_mode 决定），或错误信息
        """
        # 当前实现为同步调用，未来可以优化为真正的异步
        return self._run(pattern, path, glob, output_mode)
