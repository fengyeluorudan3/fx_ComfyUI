"""Write file tool implementation."""

from typing import Any, Dict, Optional, Union

from fx_lang_ex.utils.protocal_utils  import BackendProtocol, WriteResult

from fx_lang_ex.tools import BATool


class WriteFileTool(BATool):
    """
    写入新文件到文件系统。
    
    该工具用于创建新文件并写入内容，不能用于修改已存在的文件。
    """

    def __init__(self, backend: BackendProtocol):
        """
        初始化 WriteFileTool。
        
        Args:
            backend: 文件存储后端实例
        """
        self.backend = backend

    def get_tool_schema(self) -> Dict[str, Any]:
        """
        返回 write_file 工具的 schema 定义。
        
        Returns:
            工具的完整定义，包括参数、描述等信息
        """
        return {
            "id": "tool_filesystem_write_file",
            "name": "write_file",
            "api_domain": "写入文件",
            "description": """Writes to a new file in the filesystem.

Usage:
- The file_path parameter must be an absolute path, not a relative path
- The content parameter must be a string
- The write_file tool will create the a new file.
- Prefer to edit existing files over creating new ones when possible.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "The absolute path where the file will be created. Must start with '/'.",
                    },
                    "content": {
                        "type": "string",
                        "description": "The content to write to the file.",
                    },
                },
                "required": ["file_path", "content"],
            },
            "response": {
                "type": "object",
                "properties": {
                    "success": {
                        "type": "boolean",
                        "description": "Whether the file was written successfully.",
                    },
                    "message": {
                        "type": "string",
                        "description": "Success message or error details.",
                    },
                    "path": {
                        "type": "string",
                        "description": "The path where the file was written.",
                    },
                },
            },
            "version": "v1.0.0",
        }

    def _run(self, file_path: str, content: str) -> Dict[str, Any]:
        """
        同步执行写入文件操作。
        
        Args:
            file_path: 要创建的文件路径（绝对路径）
            content: 要写入的文件内容
            
        Returns:
            包含操作结果的字典（成功状态、消息、路径）
        """
        try:
            # 验证路径格式
            if not file_path.startswith("/"):
                return {
                    "success": False,
                    "message": "Error: File path must be an absolute path starting with '/'",
                    "path": file_path,
                }
            
            # 写入文件
            result: WriteResult = self.backend.write(file_path, content)
            
            if result.error:
                return {
                    "success": False,
                    "message": result.error,
                    "path": file_path,
                }
            
            return {
                "success": True,
                "message": f"Successfully created file '{result.path}'",
                "path": result.path,
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Error writing file: {str(e)}",
                "path": file_path,
            }

    async def _arun(self, file_path: str, content: str) -> Dict[str, Any]:
        """
        异步执行写入文件操作。
        
        Args:
            file_path: 要创建的文件路径（绝对路径）
            content: 要写入的文件内容
            
        Returns:
            包含操作结果的字典（成功状态、消息、路径）
        """
        # 当前实现为同步调用，未来可以优化为真正的异步
        return self._run(file_path, content)
