"""Read file tool implementation."""

from typing import Any, Dict, Optional


from fx_lang_ex.utils.protocal_utils import BackendProtocol
from fx_lang_ex.tools import BATool


class ReadFileTool(BATool):
    """
    从文件系统读取文件内容。
    
    该工具支持分页读取，可以读取大文件的指定部分，避免一次性加载过多内容。
    """

    DEFAULT_READ_OFFSET = 0
    DEFAULT_READ_LIMIT = 500

    def __init__(self, backend: BackendProtocol):
        """
        初始化 ReadFileTool。
        
        Args:
            backend: 文件存储后端实例
        """
        self.backend = backend

    def get_tool_schema(self) -> Dict[str, Any]:
        """
        返回 read_file 工具的 schema 定义。
        
        Returns:
            工具的完整定义，包括参数、描述等信息
        """
        return {
            "id": "tool_filesystem_read_file",
            "name": "read_file",
            "api_domain": "读取文件",
            "description": """Reads a file from the filesystem. You can access any file directly by using this tool.
Assume this tool is able to read all files on the machine. If the User provides a path to a file assume that path is valid. It is okay to read a file that does not exist; an error will be returned.

Usage:
- The file_path parameter must be an absolute path, not a relative path
- By default, it reads up to 500 lines starting from the beginning of the file
- **IMPORTANT for large files and codebase exploration**: Use pagination with offset and limit parameters to avoid context overflow
  - First scan: read_file(path, limit=100) to see file structure
  - Read more sections: read_file(path, offset=100, limit=200) for next 200 lines
  - Only omit limit (read full file) when necessary for editing
- Specify offset and limit: read_file(path, offset=0, limit=100) reads first 100 lines
- Any lines longer than 2000 characters will be truncated
- Results are returned using cat -n format, with line numbers starting at 1
- You have the capability to call multiple tools in a single response. It is always better to speculatively read multiple files as a batch that are potentially useful.
- If you read a file that exists but has empty contents you will receive a system reminder warning in place of file contents.
- You should ALWAYS make sure a file has been read before editing it.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "The absolute path to the file to read. Must start with '/'.",
                    },
                    "offset": {
                        "type": "integer",
                        "description": f"Starting line number (0-based). Default: {self.DEFAULT_READ_OFFSET}",
                        "default": self.DEFAULT_READ_OFFSET,
                    },
                    "limit": {
                        "type": "integer",
                        "description": f"Maximum number of lines to read. Default: {self.DEFAULT_READ_LIMIT}",
                        "default": self.DEFAULT_READ_LIMIT,
                    },
                },
                "required": ["file_path"],
            },
            "response": {
                "type": "string",
                "description": "File contents with line numbers, or error message if file cannot be read.",
            },
            "version": "v1.0.0",
        }

    def _run(
        self,
        file_path: str,
        offset: int = DEFAULT_READ_OFFSET,
        limit: int = DEFAULT_READ_LIMIT,
    ) -> str:
        """
        同步执行读取文件操作。
        
        Args:
            file_path: 要读取的文件路径（绝对路径）
            offset: 起始行号（从0开始）
            limit: 最大读取行数
            
        Returns:
            文件内容（带行号），或错误信息
        """
        try:
            # 验证路径格式
            if not file_path.startswith("/"):
                return "Error: File path must be an absolute path starting with '/'"
            
            # 读取文件内容
            content = self.backend.read(file_path, offset=offset, limit=limit)
            return content
        except Exception as e:
            return f"Error reading file: {str(e)}"

    async def _arun(
        self,
        file_path: str,
        offset: int = DEFAULT_READ_OFFSET,
        limit: int = DEFAULT_READ_LIMIT,
    ) -> str:
        """
        异步执行读取文件操作。
        
        Args:
            file_path: 要读取的文件路径（绝对路径）
            offset: 起始行号（从0开始）
            limit: 最大读取行数
            
        Returns:
            文件内容（带行号），或错误信息
        """
        # 当前实现为同步调用，未来可以优化为真正的异步
        return self._run(file_path, offset, limit)
