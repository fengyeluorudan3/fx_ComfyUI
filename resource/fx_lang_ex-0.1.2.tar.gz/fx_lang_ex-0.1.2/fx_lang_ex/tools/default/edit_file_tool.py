"""Edit file tool implementation."""

from typing import Any, Dict, Optional

from fx_lang_ex.utils.protocal_utils  import BackendProtocol, WriteResult

from fx_lang_ex.tools import BATool



class EditFileTool(BATool):
    """
    编辑文件系统中的文件。
    
    该工具通过精确的字符串替换来修改文件内容，支持单次替换或全部替换。
    """

    def __init__(self, backend: BackendProtocol):
        """
        初始化 EditFileTool。
        
        Args:
            backend: 文件存储后端实例
        """
        self.backend = backend

    def get_tool_schema(self) -> Dict[str, Any]:
        """
        返回 edit_file 工具的 schema 定义。
        
        Returns:
            工具的完整定义，包括参数、描述等信息
        """
        return {
            "id": "tool_filesystem_edit_file",
            "name": "edit_file",
            "api_domain": "编辑文件",
            "description": """Performs exact string replacements in files.

Usage:
- You must use your `Read` tool at least once in the conversation before editing. This tool will error if you attempt an edit without reading the file.
- When editing text from Read tool output, ensure you preserve the exact indentation (tabs/spaces) as it appears AFTER the line number prefix. The line number prefix format is: spaces + line number + tab. Everything after that tab is the actual file content to match. Never include any part of the line number prefix in the old_string or new_string.
- ALWAYS prefer editing existing files. NEVER write new files unless explicitly required.
- Only use emojis if the user explicitly requests it. Avoid adding emojis to files unless asked.
- The edit will FAIL if `old_string` is not unique in the file. Either provide a larger string with more surrounding context to make it unique or use `replace_all` to change every instance of `old_string`.
- Use `replace_all` for replacing and renaming strings across the file. This parameter is useful if you want to rename a variable for instance.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "The absolute path to the file to edit. Must start with '/'.",
                    },
                    "old_string": {
                        "type": "string",
                        "description": "The exact string to find and replace. Must be unique unless replace_all is True.",
                    },
                    "new_string": {
                        "type": "string",
                        "description": "The string to replace old_string with.",
                    },
                    "replace_all": {
                        "type": "boolean",
                        "description": "If True, replace all occurrences. If False, only replace if unique. Default: False",
                        "default": False,
                    },
                },
                "required": ["file_path", "old_string", "new_string"],
            },
            "response": {
                "type": "object",
                "properties": {
                    "success": {
                        "type": "boolean",
                        "description": "Whether the edit was successful.",
                    },
                    "message": {
                        "type": "string",
                        "description": "Success message with replacement count or error details.",
                    },
                    "occurrences": {
                        "type": "integer",
                        "description": "Number of replacements made.",
                    },
                    "path": {
                        "type": "string",
                        "description": "The path of the edited file.",
                    },
                },
            },
            "version": "v1.0.0",
        }

    def _run(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> Dict[str, Any]:
        """
        同步执行编辑文件操作。
        
        Args:
            file_path: 要编辑的文件路径（绝对路径）
            old_string: 要查找的旧字符串
            new_string: 要替换成的新字符串
            replace_all: 是否替换所有匹配项（默认False，只替换唯一匹配）
            
        Returns:
            包含操作结果的字典（成功状态、消息、替换次数、路径）
        """
        try:
            # 验证路径格式
            if not file_path.startswith("/"):
                return {
                    "success": False,
                    "message": "Error: File path must be an absolute path starting with '/'",
                    "occurrences": 0,
                    "path": file_path,
                }
            
            # 执行编辑
            result: EditResult = self.backend.edit(
                file_path, old_string, new_string, replace_all=replace_all
            )
            
            if result.error:
                return {
                    "success": False,
                    "message": result.error,
                    "occurrences": 0,
                    "path": file_path,
                }
            
            return {
                "success": True,
                "message": f"Successfully replaced {result.occurrences} instance(s) of the string in '{result.path}'",
                "occurrences": result.occurrences,
                "path": result.path,
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Error editing file: {str(e)}",
                "occurrences": 0,
                "path": file_path,
            }

    async def _arun(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> Dict[str, Any]:
        """
        异步执行编辑文件操作。
        
        Args:
            file_path: 要编辑的文件路径（绝对路径）
            old_string: 要查找的旧字符串
            new_string: 要替换成的新字符串
            replace_all: 是否替换所有匹配项（默认False，只替换唯一匹配）
            
        Returns:
            包含操作结果的字典（成功状态、消息、替换次数、路径）
        """
        # 当前实现为同步调用，未来可以优化为真正的异步
        return self._run(file_path, old_string, new_string, replace_all)
