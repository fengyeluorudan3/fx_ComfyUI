from typing import Any, Dict, Optional, List

from fx_lang_ex.utils.tool_utils import truncate_if_too_long
from fx_lang_ex.tools import BATool
from fx_agent_core.messages import ToolRequest, ToolResponse

WRITE_TODOS_SYSTEM_PROMPT = """## `write_todos`

You have access to the `write_todos` tool to help you manage and plan complex objectives.
Use this tool for complex objectives to ensure that you are tracking each necessary step and giving the user visibility into your progress.
This tool is very helpful for planning complex objectives, and for breaking down these larger complex objectives into smaller steps.

It is critical that you mark todos as completed as soon as you are done with a step. Do not batch up multiple steps before marking them as completed.
For simple objectives that only require a few steps, it is better to just complete the objective directly and NOT use this tool.
Writing todos takes time and tokens, use it when it is helpful for managing complex many-step problems! But not for simple few-step requests.

## Important To-Do List Usage Notes to Remember
- The `write_todos` tool should never be called multiple times in parallel.
- Don't be afraid to revise the To-Do list as you go. New information may reveal new tasks that need to be done, or old tasks that are irrelevant."""


class TodoTool(BATool):
    """
    Todo 管理工具，用于创建、更新、删除和查询 todo 列表。
    
    每个 todo 项包含:
    - content: 内容描述
    - status: pending / in_progress / completed
    """

    def __init__(self):
        """
        初始化 TodoTool。
        
        Args:
            backend: 存储后端，需实现 todo 相关存储 API
        """
        self.name = "write_todos"
        pass
    def get_tool_schema(self) -> Dict[str, Any]:
        """
        返回 todo 工具的 schema，供模型生成调用格式。
        """
        return {
            "name": "write_todos",
            "api_domain": "Todo 管理",
            "description": """Replace the entire TODO list with an updated checklist reflecting the current state. Always provide the full list; the system will overwrite the previous one. This tool is designed for step-by-step task tracking, allowing you to confirm completion of each step before updating, update multiple task statuses at once (e.g., mark one as completed and start the next), and dynamically add new todos discovered during long or complex tasks.

## When to Use This Tool
Use this tool in these scenarios:

1. Complex multi-step tasks - When a task requires 3 or more distinct steps or actions
2. Non-trivial and complex tasks - Tasks that require careful planning or multiple operations
3. User explicitly requests todo list - When the user directly asks you to use the todo list
4. User provides multiple tasks - When users provide a list of things to be done (numbered or comma-separated)
5. The plan may need future revisions or updates based on results from the first few steps

## How to Use This Tool
1. When you start working on a task - Mark it as in_progress BEFORE beginning work.
2. After completing a task - Mark it as completed and add any new follow-up tasks discovered during implementation.
3. You can also update future tasks, such as deleting them if they are no longer necessary, or adding new tasks that are necessary. Don't change previously completed tasks.
4. You can make several updates to the todo list at once. For example, when you complete a task, you can mark the next task you need to start as in_progress.

## When NOT to Use This Tool
It is important to skip using this tool when:
1. There is only a single, straightforward task
2. The task is trivial and tracking it provides no benefit
3. The task can be completed in less than 3 trivial steps
4. The task is purely conversational or informational

**Core Principles:**
- Before updating, always confirm which todos have been completed since the last update.
- You may update multiple statuses in a single update (e.g., mark the previous as completed and the next as in progress).
- When a new actionable item is discovered during a long or complex task, add it to the todo list immediately.
- Do not remove any unfinished todos unless explicitly instructed.
- Always retain all unfinished tasks, updating their status as needed.
- Only mark a task as completed when it is fully accomplished (no partials, no unresolved dependencies).
- If a task is blocked, keep it as in_progress and add a new todo describing what needs to be resolved.
- Remove tasks only if they are no longer relevant or if the user requests deletion.


## Task States and Management

1. **Task States**: Use these states to track progress:
   - pending: Task not yet started
   - in_progress: Currently working on (you can have multiple tasks in_progress at a time if they are not related to each other and can be run in parallel)
   - completed: Task finished successfully

2. **Task Management**:
   - Update task status in real-time as you work
   - Mark tasks complete IMMEDIATELY after finishing (don't batch completions)
   - Complete current tasks before starting new ones
   - Remove tasks that are no longer relevant from the list entirely
   - IMPORTANT: When you write this todo list, you should mark your first task (or tasks) as in_progress immediately!.
   - IMPORTANT: Unless all tasks are completed, you should always have at least one task in_progress to show the user that you are working on something.

3. **Task Completion Requirements**:
   - ONLY mark a task as completed when you have FULLY accomplished it
   - If you encounter errors, blockers, or cannot finish, keep the task as in_progress
   - When blocked, create a new task describing what needs to be resolved
   - Never mark a task as completed if:
     - There are unresolved issues or errors
     - Work is partial or incomplete
     - You encountered blockers that prevent completion
     - You couldn't find necessary resources or dependencies
     - Quality standards haven't been met

4. **Task Breakdown**:
   - Create specific, actionable items
   - Break complex tasks into smaller, manageable steps
   - Use clear, descriptive task names

Being proactive with task management demonstrates attentiveness and ensures you complete all requirements successfully
Remember: If you only need to make a few tool calls to complete a task, and it is clear what you need to do, it is better to just do the task directly and NOT call this tool at all.""",

            "parameters": {
                "type": "object",
                "properties": {
                    "todos": {
                        "type": "array",
                        "description": "Structured todo list for the current objective",
                        "items": {
                            "type": "object",
                            "properties": {
                                "content": {
                                    "type": "string",
                                    "description": "Todo task description"
                                },
                                "status": {
                                    "type": "string",
                                    "enum": ["pending", "in_progress", "completed"],
                                    "description": "Current task status"
                                }
                            },
                            "required": ["content"]
                        }
                    }
                },
                "required": ["todos"]
            },
            "version": "v1.0.0",
        }

    def _run(self, tool_request: ToolRequest, **kwargs: Any) -> ToolResponse:
        params = tool_request.params or {}
        tool_call_id = tool_request.tool_call_id

        todos = params.get("todos")

        print("todos============================================",todos)
        if not todos or not isinstance(todos, list):
            return ToolResponse(
                name=self.name,
                params=params,
                tool_call_id=tool_call_id,
                code=1,
                msg="Invalid arguments",
                res_content="write_todos 需要提供 todos 数组",
                res_datas=None,
                artifacts=[],
            )

        # 校验 todos 结构
        normalized_todos = []
        for idx, todo in enumerate(todos):
            content = todo.get("content")
            status = todo.get("status", "pending")

            if not content:
                return ToolResponse(
                    name=self.name,
                    params=params,
                    tool_call_id=tool_call_id,
                    code=1,
                    msg="Invalid todo item",
                    res_content=f"第 {idx} 个 todo 缺少 content",
                    res_datas=None,
                    artifacts=[],
                )

            if status not in ("pending", "in_progress", "completed"):
                return ToolResponse(
                    name=self.name,
                    params=params,
                    tool_call_id=tool_call_id,
                    code=1,
                    msg="Invalid todo status",
                    res_content=f"todo[{idx}] status 不合法: {status}",
                    res_datas=None,
                    artifacts=[],
                )

            normalized_todos.append({
                "content": content,
                "status": status,
            })

        try:
            lines = []
            for i, t in enumerate(normalized_todos):
                lines.append(f"{i}. [{t['status']}] {t['content']}")

            res_content = "Todo 列表已更新：\n" + "\n".join(lines)

            return ToolResponse(
                name=self.name,
                params=params,
                tool_call_id=tool_call_id,
                code=0,
                msg="OK",
                res_content="Todo 列表已更新",
                res_datas=None,
                artifacts=[],
            )

        except Exception as e:
            return ToolResponse(
                name=self.name,
                params=params,
                tool_call_id=tool_call_id,
                code=1,
                msg=str(e),
                res_content=f"写入 todo 失败：{e}",
                res_datas=None,
                artifacts=[],
            )

    async def _arun(self, tool_request: ToolRequest, **kwargs: Any) -> ToolResponse:
        """
        异步执行（目前直接调用同步版本）
        """
        return self._run(tool_request, kwargs)
