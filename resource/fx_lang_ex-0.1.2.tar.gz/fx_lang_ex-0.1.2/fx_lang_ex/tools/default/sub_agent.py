# import asyncio
# import time
# import logging
# from typing import Any, Dict, Optional, List
#
# from fx_lang_ex.utils.tool_utils import truncate_if_too_long
# from fx_lang_ex.tools import BATool
# from fx_agent_core.messages import ToolRequest, ToolResponse
# from fx_agent_core import FxAgent
#
# logger = logging.getLogger(__name__)
#
# WRITE_TODOS_SYSTEM_PROMPT = """## `write_todos`
#
# You have access to the `write_todos` tool to help you manage and plan complex objectives.
# Use this tool for complex objectives to ensure that you are tracking each necessary step and giving the user visibility into your progress.
# This tool is very helpful for planning complex objectives, and for breaking down these larger complex objectives into smaller steps.
#
# It is critical that you mark todos as completed as soon as you are done with a step. Do not batch up multiple steps before marking them as completed.
# For simple objectives that only require a few steps, it is better to just complete the objective directly and NOT use this tool.
# Writing todos takes time and tokens, use it when it is helpful for managing complex many-step problems! But not for simple few-step requests.
#
# ## Important To-Do List Usage Notes to Remember
# - The `write_todos` tool should never be called multiple times in parallel.
# - Don't be afraid to revise the To-Do list as you go. New information may reveal new tasks that need to be done, or old tasks that are irrelevant."""
#
#
# class SubAgentTool(BATool):
#     """
#     子 Agent 工具，用于创建并运行一个子 agent 来处理特定任务。
#
#     子 agent 可以独立运行，有自己的模型配置、agent 配置和工具集。
#     """
#
#     def __init__(self):
#         """
#         初始化 SubAgentTool。
#         """
#         self.name = "sub_agent"
#
#     def get_tool_schema(self) -> Dict[str, Any]:
#         """
#         返回 sub_agent 工具的 schema，供模型生成调用格式。
#         """
#         return {
#             "name": "sub_agent",
#             "api_domain": "子 Agent 执行",
#             "description": """Use this tool to create and run a sub-agent to handle a specific task.
# The sub-agent runs independently with its own model configuration, agent configuration, and tools.
#
# Use this tool when:
# 1. You need to delegate a complex task to a specialized agent
# 2. The task requires a different model or agent configuration
# 3. The task needs specific tools that are not available in the current context
# 4. You want to isolate a task execution from the main agent flow
#
# The sub-agent will execute the task and return the result.""",
#
#             "parameters": {
#                 "type": "object",
#                 "properties": {
#                     "query": {
#                         "type": "string",
#                         "description": "The task query for the sub-agent to execute"
#                     },
#                     "model_infos": {
#                         "type": "object",
#                         "description": "Model configuration for the sub-agent. If not provided, will use default values.",
#                         "properties": {
#                             "model_name": {"type": "string"},
#                             "temperature": {"type": "number"},
#                             "max_tokens": {"type": "integer"},
#                             "seed": {"type": "integer"}
#                         }
#                     },
#                     "agent_infos": {
#                         "type": "object",
#                         "description": "Agent configuration for the sub-agent. If not provided, will use default values.",
#                         "properties": {
#                             "agent_type": {"type": "string"},
#                             "max_react_loop_num": {"type": "integer"},
#                             "system_prompt": {"type": "string"}
#                         }
#                     },
#                     "ba_context": {
#                         "type": "object",
#                         "description": "BA context information for the sub-agent"
#                     }
#                 },
#                 "required": ["query"]
#             },
#             "version": "v1.0.0",
#         }
#
#     def _run(self, tool_request: ToolRequest, **kwargs: Any) -> ToolResponse:
#         """
#         同步执行子 agent 工具。
#
#         Args:
#             tool_request: 工具请求
#             **kwargs: 额外参数
#
#         Returns:
#             ToolResponse: 工具响应
#         """
#         params = tool_request.params or {}
#         tool_call_id = tool_request.tool_call_id
#
#         # 1. 获取必需参数
#         query = params.get("query")
#         if not query:
#             return ToolResponse(
#                 name=self.name,
#                 params=params,
#                 tool_call_id=tool_call_id,
#                 code=1,
#                 msg="Invalid arguments",
#                 res_content="sub_agent 需要提供 query 参数",
#                 res_datas=None,
#                 artifacts=[],
#             )
#
#         # 2. 获取可选参数，使用默认值
#         model_infos = params.get("model_infos", {
#             "temperature": 0.5,
#             "model_name": "qwen3-vl:235b-cloud",
#             "seed": 0,
#             "thinking": "auto",
#             "max_tokens": 4096,
#             "top_n": 1.0,
#             "ba_version": 1,
#         })
#
#         agent_infos = params.get("agent_infos", {
#             "utterance_start": "<|im_start|>",
#             "utterance_end": "<|im_end|>",
#             "inner_seg": "\n",
#             "inter_seg": "\n",
#             "agent_type": "fx_react_agent",
#             "max_react_loop_num": 3,
#             "system_prompt": "",
#         })
#
#         ba_context = params.get("ba_context", {
#             "x-use-ppe": "1",
#             "x-tt-env": "ppe_comfy_agentnode",
#         })
#
#         # 3. 构建 context
#         context = {
#             "request": {
#                 "query": query,
#             },
#             "mock": False,
#             "ba_context": ba_context,
#             "tool_call_id": tool_call_id,
#             "params": params,
#         }
#
#         # 4. 运行子 agent（异步）
#         try:
#             result = asyncio.run(self._run_sub_agent(model_infos, agent_infos, context, []))
#             return result
#         except Exception as e:
#             logger.error(f"[SubAgent] 执行失败: {e}", exc_info=True)
#             return ToolResponse(
#                 name=self.name,
#                 params=params,
#                 tool_call_id=tool_call_id,
#                 code=1,
#                 msg=str(e),
#                 res_content=f"子 agent 执行失败：{e}",
#                 res_datas=None,
#                 artifacts=[],
#             )
#
#     async def _run_sub_agent(
#         self,
#         model_infos: Dict[str, Any],
#         agent_infos: Dict[str, Any],
#         context: Dict[str, Any],
#         tools: List[BATool]
#     ) -> ToolResponse:
#         """
#         异步运行子 agent。
#
#         Args:
#             model_infos: 模型配置
#             agent_infos: Agent 配置
#             context: 上下文
#             tools: 工具列表
#
#         Returns:
#             ToolResponse: 工具响应
#         """
#         start_time = time.time()
#         tool_call_id = context.get("tool_call_id", "")
#         params = context.get("params", {})
#
#         # 创建子 agent
#         agent = FxAgent()
#         agent.init(model_infos, agent_infos, tools)
#
#         # 用于收集结果
#         stream_results = {
#             "stream_count": 0,
#             "response_data": None,
#             "raw_text": "",
#             "display_text": "",
#             "final_content": "",
#             "artifacts": [],
#         }
#
#         async def process_stream():
#             """处理流式消息的协程"""
#             logger.info("[SubAgent] process_stream 开始...")
#             try:
#                 async for chunk in agent.channel.stream_generator():
#                     stream_results["stream_count"] += 1
#                     stream_results["response_data"] = chunk
#
#                     delta_content = chunk.get("response", {}).get("delta_content", {})
#
#                     if delta_content.get("content_type") == "text":
#                         text_content = delta_content.get("content", "")
#                         if text_content:
#                             stream_results["raw_text"] += text_content
#                             stream_results["display_text"] = stream_results["raw_text"]
#
#                     # 收集 artifacts
#                     response = chunk.get("response", {})
#                     if response.get("artifacts"):
#                         stream_results["artifacts"].extend(response.get("artifacts", []))
#
#             except Exception as e:
#                 logger.error(f"[SubAgent] process_stream 错误: {e}", exc_info=True)
#             finally:
#                 # 提取最终内容
#                 if stream_results["response_data"]:
#                     response = stream_results["response_data"].get("response", {})
#                     stream_results["final_content"] = response.get("content", stream_results["display_text"])
#                 else:
#                     stream_results["final_content"] = stream_results["display_text"]
#
#                 logger.info(
#                     f"[SubAgent] process_stream 结束，共收到 {stream_results['stream_count']} 条消息，"
#                     f"final_content: {stream_results['final_content'][:100] if stream_results['final_content'] else '空'}..."
#                 )
#
#         async def run_agent():
#             """运行 agent 的协程"""
#             logger.info("[SubAgent] run_agent 开始...")
#             try:
#                 await agent.run(context)
#                 logger.info("[SubAgent] run_agent 完成")
#             except TypeError as e:
#                 if "with_traceback" not in str(e):
#                     raise
#                 logger.warning(f"Ignoring fx_agent_core internal error: {e}")
#             except Exception as e:
#                 logger.error(f"[SubAgent] run_agent 错误: {e}", exc_info=True)
#                 raise
#
#         # 并行运行 agent 和流式处理
#         logger.info("[SubAgent] 创建并行任务...")
#         stream_task = asyncio.create_task(process_stream())
#         agent_task = asyncio.create_task(run_agent())
#
#         # 等待两个任务完成
#         try:
#             await agent_task
#         except Exception as e:
#             logger.error(f"[SubAgent] Agent task error: {e}")
#             raise
#
#         try:
#             await stream_task
#         except Exception as e:
#             logger.error(f"[SubAgent] Stream task error: {e}")
#
#         # 计算延迟
#         latency_ms = (time.time() - start_time) * 1000
#         logger.info(f"[SubAgent] 执行完成，耗时 {latency_ms:.2f}ms")
#
#         # 构建响应
#         final_content = stream_results["final_content"]
#         if not final_content:
#             final_content = "子 agent 执行完成，但未返回内容"
#
#         return ToolResponse(
#             name=self.name,
#             params=params,
#             tool_call_id=tool_call_id,
#             code=0,
#             msg="OK",
#             res_content=truncate_if_too_long(final_content),
#             res_datas={
#                 "latency_ms": latency_ms,
#                 "stream_count": stream_results["stream_count"],
#             },
#             artifacts=stream_results["artifacts"],
#         )
#
#     async def _arun(self, tool_request: ToolRequest, **kwargs: Any) -> ToolResponse:
#         """
#         异步执行（直接调用异步版本）
#         """
#         params = tool_request.params or {}
#         tool_call_id = tool_request.tool_call_id
#
#         # 获取必需参数
#         query = params.get("query")
#         if not query:
#             return ToolResponse(
#                 name=self.name,
#                 params=params,
#                 tool_call_id=tool_call_id,
#                 code=1,
#                 msg="Invalid arguments",
#                 res_content="sub_agent 需要提供 query 参数",
#                 res_datas=None,
#                 artifacts=[],
#             )
#
#         # 获取可选参数，使用默认值
#         model_infos = params.get("model_infos", {
#             "temperature": 0.5,
#             "model_name": "qwen3-vl:235b-cloud",
#             "seed": 0,
#             "thinking": "auto",
#             "max_tokens": 4096,
#             "top_n": 1.0,
#             "ba_version": 1,
#         })
#
#         agent_infos = params.get("agent_infos", {
#             "utterance_start": "<|im_start|>",
#             "utterance_end": "<|im_end|>",
#             "inner_seg": "\n",
#             "inter_seg": "\n",
#             "agent_type": "fx_react_agent",
#             "max_react_loop_num": 3,
#             "system_prompt": "",
#         })
#
#         ba_context = params.get("ba_context", {
#             "x-use-ppe": "1",
#             "x-tt-env": "ppe_comfy_agentnode",
#         })
#
#         # 构建 context
#         context = {
#             "request": {
#                 "query": query,
#             },
#             "mock": False,
#             "ba_context": ba_context,
#             "tool_call_id": tool_call_id,
#             "params": params,
#         }
#
#         try:
#             return await self._run_sub_agent(model_infos, agent_infos, context, [])
#         except Exception as e:
#             logger.error(f"[SubAgent] 异步执行失败: {e}", exc_info=True)
#             return ToolResponse(
#                 name=self.name,
#                 params=params,
#                 tool_call_id=tool_call_id,
#                 code=1,
#                 msg=str(e),
#                 res_content=f"子 agent 执行失败：{e}",
#                 res_datas=None,
#                 artifacts=[],
#             )
