"""Glob pattern matching tool implementation."""

from typing import Any, Dict, Optional

from fx_lang_ex.utils.protocal_utils import BackendProtocol
from fx_lang_ex.utils.tool_utils import truncate_if_too_long
from fx_lang_ex.tools import BATool



class GlobTool(BATool):
    """
    使用 glob 模式查找文件。
    
    该工具支持标准 glob 通配符模式，可以快速查找符合特定模式的文件。
    """

    def __init__(self, backend: BackendProtocol):
        """
        初始化 GlobTool。
        
        Args:
            backend: 文件存储后端实例
        """
        self.backend = backend

    def get_tool_schema(self) -> Dict[str, Any]:
        """
        返回 glob 工具的 schema 定义。
        
        Returns:
            工具的完整定义，包括参数、描述等信息
        """
        return {
            "id": "tool_filesystem_glob",
            "name": "glob",
            "api_domain": "模式匹配查找文件",
            "description": """Find files matching a glob pattern.

Usage:
- The glob tool finds files by matching patterns with wildcards
- Supports standard glob patterns: `*` (any characters), `**` (any directories), `?` (single character)
- Patterns can be absolute (starting with `/`) or relative
- Returns a list of absolute file paths that match the pattern

Examples:
- `**/*.py` - Find all Python files
- `*.txt` - Find all text files in root
- `/subdir/**/*.md` - Find all markdown files under /subdir""",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "The glob pattern to match files. Supports *, **, and ? wildcards.",
                    },
                    "path": {
                        "type": "string",
                        "description": "The starting directory path for the search. Default: '/'",
                        "default": "/",
                    },
                },
                "required": ["pattern"],
            },
            "response": {
                "type": "string",
                "description": "List of file paths matching the pattern, or error message.",
            },
            "version": "v1.0.0",
        }

    def _run(self, pattern: str, path: str = "/") -> str:
        """
        同步执行 glob 模式匹配操作。
        
        Args:
            pattern: glob 模式字符串（支持 *, **, ? 通配符）
            path: 搜索起始路径（默认为根目录）
            
        Returns:
            匹配的文件路径列表字符串，或错误信息
        """
        try:
            # 验证路径格式
            if not path.startswith("/"):
                return "Error: Path must be an absolute path starting with '/'"
            
            # 执行 glob 查找
            infos = self.backend.glob_info(pattern, path=path)
            paths = [fi.get("path", "") for fi in infos]
            
            if not paths:
                return f"No files found matching pattern: {pattern}"
            
            # 截断过长的输出
            result = truncate_if_too_long(paths)
            return str(result)
        except Exception as e:
            return f"Error searching with glob pattern: {str(e)}"

    async def _arun(self, pattern: str, path: str = "/") -> str:
        """
        异步执行 glob 模式匹配操作。
        
        Args:
            pattern: glob 模式字符串（支持 *, **, ? 通配符）
            path: 搜索起始路径（默认为根目录）
            
        Returns:
            匹配的文件路径列表字符串，或错误信息
        """
        # 当前实现为同步调用，未来可以优化为真正的异步
        return self._run(pattern, path)
