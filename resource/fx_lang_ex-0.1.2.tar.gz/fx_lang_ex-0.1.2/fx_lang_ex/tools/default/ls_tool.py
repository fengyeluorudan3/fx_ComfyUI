"""List files tool implementation."""

from typing import Any, Dict, Optional

from fx_lang_ex.utils.protocal_utils import BackendProtocol
from fx_lang_ex.utils.tool_utils import truncate_if_too_long
from fx_lang_ex.tools import BATool


class LsTool(BATool):
    """
    列出文件系统中的文件和目录。
    
    该工具用于浏览文件系统结构，查看指定目录下的所有文件和子目录。
    """

    def __init__(self, backend: BackendProtocol):
        """
        初始化 LsTool。
        
        Args:
            backend: 文件存储后端实例
        """
        self.backend = backend

    def get_tool_schema(self) -> Dict[str, Any]:
        """
        返回 ls 工具的 schema 定义。
        
        Returns:
            工具的完整定义，包括参数、描述等信息
        """
        return {
            "id": "tool_filesystem_ls",
            "name": "ls",
            "api_domain": "列出文件",
            "description": """
Lists all files in the filesystem, filtering by directory.

Usage:
- The path parameter must be an absolute path, not a relative path
- The list_files tool will return a list of all files in the specified directory.
- This is very useful for exploring the file system and finding the right file to read or edit.
- You should almost ALWAYS use this tool before using the Read or Edit tools.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "The absolute path to the directory to list files from. Must start with '/'.",
                    }
                },
                "required": ["path"],
            },
            "response": {
                "type": "string",
                "description": "A list of file paths in the directory, or error message if path is invalid.",
            },
            "version": "v1.0.0",
        }

    def _run(self, path: str) -> str:
        """
        同步执行列出文件操作。
        
        Args:
            path: 要列出文件的目录路径（绝对路径）
            
        Returns:
            目录中的文件列表字符串，或错误信息
        """
        try:
            # 验证路径格式
            if not path.startswith("/"):
                return "Error: Path must be an absolute path starting with '/'"
            
            # 获取文件信息列表
            infos = self.backend.ls_info(path)
            paths = [fi.get("path", "") for fi in infos]
            
            # 截断过长的输出
            result = truncate_if_too_long(paths)
            return str(result)
        except Exception as e:
            return f"Error listing files: {str(e)}"

    async def _arun(self, path: str) -> str:
        """
        异步执行列出文件操作。
        
        Args:
            path: 要列出文件的目录路径（绝对路径）
            
        Returns:
            目录中的文件列表字符串，或错误信息
        """
        # 当前实现为同步调用，未来可以优化为真正的异步
        return self._run(path)
