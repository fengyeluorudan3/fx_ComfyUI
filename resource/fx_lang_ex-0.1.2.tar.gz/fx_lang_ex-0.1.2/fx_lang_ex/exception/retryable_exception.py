class RetryableException(Exception):
    pass