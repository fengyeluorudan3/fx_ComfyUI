from enum import Enum


class ResponseCode(Enum):
    """
    通用响应状态码定义。
    """

    SUCCESS = (0, "OK")
    INVALID_PARAM = (1001, "Invalid parameter")
    NOT_FOUND = (1002, "Resource not found")
    UNAUTHORIZED = (1003, "Unauthorized access")
    SERVER_ERROR = (2000, "Internal server error")

    def __init__(self, code: int, msg: str):
        self._code = code
        self._msg = msg

    @property
    def code(self) -> int:
        """返回状态码"""
        return self._code

    @property
    def msg(self) -> str:
        """返回描述信息"""
        return self._msg
