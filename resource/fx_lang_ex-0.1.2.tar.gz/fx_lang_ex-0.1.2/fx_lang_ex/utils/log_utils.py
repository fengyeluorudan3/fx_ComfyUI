import time
import json
import logging

# 配置日志记录器
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("fx_agent_logger")


class AgentLog(object):
    """
    Agent 日志。
    """

    def __init__(self, content: str):
        """
        初始化方法。

        Args:
            content: str, 日志信息
        """
        self.content = content

    @classmethod
    def from_copilot_request(cls, copilot_request):
        """
        Copilot 请求日志。
        """
        log_content = json.dumps(copilot_request, ensure_ascii=False)
        return cls(log_content)

    @classmethod
    def from_agent_request(cls, agent_request):
        """
        Agent 请求日志。
        """
        log_content = {
            "query": agent_request.query,
            "history": agent_request.history if agent_request.history else []
        }
        log_content = json.dumps(log_content, ensure_ascii=False)
        return cls(log_content)

    @classmethod
    def from_agent_response(cls, agent_response):
        """
        Agent 响应日志。
        """
        log_content = {
            "session_id": agent_response.session_id,
            "related_user_msg_id": agent_response.related_user_msg_id,
            "msg_id": agent_response.msg_id,
            "render_template": agent_response.render_template,
            "content": agent_response.msg,
            "orig_llm_output": agent_response.orig_llm_output,
            "artifacts": [
                {"placeholder": item.get("placeholder", "")}
                for item in (agent_response.artifacts or [])
            ],
            "tools": agent_response.tools or [],
            "agent_id": agent_response.agent_id,
            "agent_name": agent_response.agent_name,
            "code": agent_response.code,
            "msg": agent_response.msg,
            "agent_result": agent_response.agent_result
        }
        log_content = json.dumps(log_content, ensure_ascii=False)
        return cls(log_content)

    @classmethod
    def from_kv(cls, **kwargs):
        """
        通用日志。
        """
        try:
            log_content = json.dumps(kwargs, ensure_ascii=False)
        except Exception:
            log_content = "{}"
        return cls(log_content)

    @classmethod
    def from_llm_request(cls, llm_request):
        """
        大模型请求日志。
        """
        log_content = {
            "traceId": llm_request._copilot_infos.get("traceId", "") if llm_request._copilot_infos else "",
            "system": llm_request.system,
            "messages": llm_request.messages,
            # "artifacts": [
            #     {"placeholder": item.get("placeholder", "")}
            #     for item in (llm_request.artifacts or [])
            # ],
            "tools": [
                {key: tool.get(key) for key in ["id", "name", "api_domain", "description", "parameters"]}
                for tool in (llm_request.tools or [])
            ]
        }
        log_content = json.dumps(log_content, ensure_ascii=False)
        return cls(log_content)

    @classmethod
    def from_tool_request(cls, tool_request):
        """
        工具请求日志。
        """
        log_content = {
            "traceId": tool_request._copilot_infos.get("traceId", "") if tool_request._copilot_infos else "",
            "name": tool_request.name,
            "params": tool_request.params,
            "tool_call_id": tool_request.tool_call_id,
            "artifacts": [
                {"placeholder": item.get("placeholder", "")}
                for item in (tool_request.artifacts or [])
            ]
        }
        log_content = json.dumps(log_content, ensure_ascii=False)
        return cls(log_content)

    @classmethod
    def from_tool_response(cls, tool_response):
        """
        工具响应日志。
        """
        log_content = {
            "traceId": tool_response._copilot_infos.get("traceId", "") if tool_response._copilot_infos else "",
            "name": tool_response.name,
            "params": tool_response.params,
            "tool_call_id": tool_response.tool_call_id,
            "artifacts": [
                {"placeholder": item.get("placeholder", "")}
                for item in (tool_response.artifacts or [])
            ],
            "code": tool_response.code,
            "msg": tool_response.msg,
            "res_content": tool_response.res_content,
            "res_datas": tool_response.res_datas
        }
        log_content = json.dumps(log_content, ensure_ascii=False)
        return cls(log_content)

    @property
    def log_content(self):
        """返回日志内容字符串"""
        return self.content


def log_exec_time(log_name: str):
    """
    执行时间日志装饰器。
    """

    def exec_time(func):
        def func_wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()
            elapsed = end_time - start_time
            logger.info(
                f"[*] [Time Elapsed] {json.dumps({'name': log_name, 'exec_time': f'{elapsed:.3f}'}, ensure_ascii=False)}"
            )
            return result
        return func_wrapper

    return exec_time
