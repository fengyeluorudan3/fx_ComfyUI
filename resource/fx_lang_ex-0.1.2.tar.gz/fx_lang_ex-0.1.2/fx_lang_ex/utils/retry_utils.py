import asyncio
import functools
from fx_lang_ex.exception import RetryableException
from fx_lang_ex.utils.log_utils import logger


def retry_on_retryable_exception(
    delays=(5, 10, 20),
    jitter_ratio=0.3
):
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):

            total_attempts = len(delays) + 1

            for attempt in range(1, total_attempts + 1):
                try:
                    async for token in func(*args, **kwargs):
                        yield token
                    return
                except RetryableException:
                    # 如果还有机会重试
                    if attempt <= len(delays):
                        base_delay = delays[attempt - 1]
                        jitter = base_delay * jitter_ratio
                        real_delay = base_delay + random.uniform(-jitter, jitter)

                        logger.warning(
                            f"RetryableException，第 {attempt} 次尝试失败，"
                            f"基础 {base_delay}s + 抖动 = {real_delay:.2f}s"
                        )

                        await asyncio.sleep(max(0, real_delay))
                    else:
                        # 已经超过最大重试次数
                        logger.error("[*] exceed_retry_limit_times")
                        raise
                except Exception as e:
                    logger.error(f"[*] no_retryable_exception: {e}")
                    raise

            logger.error("[*] 重试后仍失败，终止请求")
            raise Exception("remote_egress_gateway_exception:please retry later")

        return wrapper
    return decorator
