import datetime


def get_current_date(format_str: str = "%Y-%m-%d") -> str:
    """
    获取当前日期（年月日）的字符串。

    Args:
        format_str (str): 日期格式字符串，默认 "%Y-%m-%d"（如 2025-10-09）。
                         支持格式:
                         - %Y: 年（4位）
                         - %m: 月（2位）
                         - %d: 日（2位）

                         示例：
                         "%Y年%m月%d日" → "2025年10月09日"
                         "%Y%m%d" → "20251009"

    Returns:
        str: 格式化后的当前日期字符串。
    """
    current_time = datetime.datetime.now()  # 获取本地时间
    return current_time.strftime(format_str)
