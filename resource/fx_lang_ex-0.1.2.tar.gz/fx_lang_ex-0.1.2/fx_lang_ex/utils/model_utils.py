def get_model_scope(model_name: str):
    """获取模型的模型范围"""
    if model_name in ("Doubao-Seed-1.6",
                      "Doubao-1.5-vision-pro-32k",
                      "gpt-5-chat-2025-08-07",
                      "gpt-4o-2024-11-28",
                      "gpt-4-1-2025-04-14",
                      "gpt-4-1-mini-2025-04-14",
                      "gemini-2.5-pro",
                      "gemini-2.5-flash"):
        return "国内, 文本"
    return "文本"