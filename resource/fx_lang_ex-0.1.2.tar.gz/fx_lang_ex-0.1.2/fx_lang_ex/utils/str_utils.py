import json
from typing import Any


def prepare_obj_for_jsonify(obj: Any):
    """
    用于将 obj 转换为可 json 化的对象。

    Args:
        obj: 待转换对象

    Returns:
        new_obj: 可 json 化的对象
    """
    if obj is None or type(obj) in [str, bool, int, float]:
        return obj

    # 如果对象有自定义序列化方法
    if type(obj) not in [list, dict, tuple]:
        if hasattr(obj, "to_json"):
            return json.loads(obj.to_json())

        classname = obj.__class__.__name__
        obj_id = id(obj)
        return {"type": "object", "class": classname, "id": obj_id}

    # 列表或元组递归转换
    if type(obj) in [list, tuple]:
        new_list = []
        for v in obj:
            new_v = prepare_obj_for_jsonify(v)
            new_list.append(new_v)
        return new_list

    # 字典递归转换
    if type(obj) in [dict]:
        new_dict = {}
        for key in obj:
            new_dict[key] = prepare_obj_for_jsonify(obj[key])
        return new_dict

    # 其他类型转换为字符串
    return str(obj)
