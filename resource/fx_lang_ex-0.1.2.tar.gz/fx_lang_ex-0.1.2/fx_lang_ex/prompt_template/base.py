from abc import abstractmethod


"""
基础 Prompt 模板类。

设计思路：
- Role（人物设定）
- Behavior Constraints（行为约束）
- Goals & Workflow（目标和链路化工作流）
- Environment & Memory（环境与记忆状态）
- Dynamic Information（动态信息段）
"""


class BasePromptTemplate(object):
    """
    Prompt 模板基类。
    """

    def __init__(self):
        """
        初始化方法。

        Args:
            config: dict, PromptBuilder 配置

        Returns:
            None
        """
        pass

    @abstractmethod
    def build(self, request: dict = None, agent_conf: dict = None, **kwargs):
        """
        构建方法。

        Args:
            request: dict, LlmRequest / AgentRequest 信息
            agent_conf: dict, agent 配置

        Returns:
            prompt: Union[str, List[dict(str, str)]], 构建结果 prompt
        """
        pass
